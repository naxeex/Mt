package com.intimedevs.droidforge.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import com.intimedevs.droidforge.core.common.AppResult
import com.intimedevs.droidforge.core.common.FileSizeFormatter
import com.intimedevs.droidforge.core.fileops.ConflictPolicy
import com.intimedevs.droidforge.core.fileops.FileOperationsEngine
import com.intimedevs.droidforge.core.storage.FileNode
import com.intimedevs.droidforge.core.storage.StorageRepository
import com.intimedevs.droidforge.feature.apkinspector.ApkInspectionReport
import com.intimedevs.droidforge.feature.apkinspector.ApkParserEngine
import com.intimedevs.droidforge.feature.appmanager.InstalledAppItem
import com.intimedevs.droidforge.feature.appmanager.InstalledAppsRepository
import com.intimedevs.droidforge.feature.archive.ZipArchiveEngine
import com.intimedevs.droidforge.feature.hexviewer.ChunkedHexReader
import com.intimedevs.droidforge.feature.hexviewer.HexPage
import com.intimedevs.droidforge.feature.texteditor.EditorDocumentState
import com.intimedevs.droidforge.feature.texteditor.TextEditorEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class FileAction {
    TEXT, HEX, APK, ZIP, ZIP_EXTRACT_WORKSPACE, ZIP_EXTRACT_CURRENT, CHECKSUM, RENAME, DELETE, COPY_TO_WORKSPACE
}

enum class TopDestination(val label: String) {
    HOME("Home"), FILES("Files"), APPS("Apps"), TOOLS("Tools"), TASKS("Tasks"), SETTINGS("Settings")
}

data class SessionTaskEntry(
    val id: Long,
    val title: String,
    val detail: String,
    val succeeded: Boolean,
    val timestampMillis: Long = System.currentTimeMillis()
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DroidForgeAppRoot() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val storageRepo = remember { StorageRepository(context) }
    val fileOps = remember { FileOperationsEngine() }
    val zipEngine = remember { ZipArchiveEngine() }
    val hexReader = remember { ChunkedHexReader() }
    val apkEngine = remember { ApkParserEngine(fileOps) }
    val textEngine = remember { TextEditorEngine() }
    val appsRepo = remember { InstalledAppsRepository(context) }

    val workspaceRoot = remember { File(context.filesDir, "Workspace").apply { mkdirs() } }
    var currentTab by remember { mutableStateOf(TopDestination.HOME) }
    var showOnboarding by remember { mutableStateOf(false) }
    var currentDir by remember { mutableStateOf(workspaceRoot) }
    var safStack by remember { mutableStateOf<List<Uri>>(emptyList()) }
    val currentSafUri = safStack.lastOrNull()
    var files by remember { mutableStateOf<List<FileNode>>(emptyList()) }
    var includeHidden by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var statusBanner by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var selectedNode by remember { mutableStateOf<FileNode?>(null) }

    // Multi-select & Clipboard state
    var multiSelectMode by remember { mutableStateOf(false) }
    var selectedIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var clipboardNodes by remember { mutableStateOf<List<FileNode>>(emptyList()) }
    var clipboardIsMove by remember { mutableStateOf(false) }
    var conflictPolicy by remember { mutableStateOf(ConflictPolicy.KEEP_BOTH) }

    // Batch Rename & Create ZIP Dialogs
    var showBatchRenameDialog by remember { mutableStateOf(false) }
    var batchPrefix by remember { mutableStateOf("") }
    var batchSuffix by remember { mutableStateOf("") }
    var batchFind by remember { mutableStateOf("") }
    var batchReplace by remember { mutableStateOf("") }
    var batchUseNumbering by remember { mutableStateOf(false) }
    var showCreateZipDialog by remember { mutableStateOf(false) }
    var zipArchiveName by remember { mutableStateOf("archive.zip") }

    // Dialog & Report state
    var reportTitle by remember { mutableStateOf("") }
    var reportBody by remember { mutableStateOf("") }
    var showReport by remember { mutableStateOf(false) }
    var showFolderDialog by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var nameInput by remember { mutableStateOf("") }

    // Text Editor state
    var editorTitle by remember { mutableStateOf("") }
    var editorState by remember { mutableStateOf<EditorDocumentState?>(null) }
    var editorFile by remember { mutableStateOf<File?>(null) }
    var editorUri by remember { mutableStateOf<Uri?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var showFindReplaceBar by remember { mutableStateOf(false) }
    var editorFindQuery by remember { mutableStateOf("") }
    var editorReplaceText by remember { mutableStateOf("") }
    var editorUseRegex by remember { mutableStateOf(false) }
    var editorCaseSensitive by remember { mutableStateOf(false) }
    var editorMatchSummary by remember { mutableStateOf<String?>(null) }

    // Interactive Hex Viewer & Editor state
    var showHexDialog by remember { mutableStateOf(false) }
    var hexTitle by remember { mutableStateOf("") }
    var hexWorkingFile by remember { mutableStateOf<File?>(null) }
    var hexOriginSafUri by remember { mutableStateOf<Uri?>(null) }
    var hexPage by remember { mutableStateOf<HexPage?>(null) }
    var hexOffsetInput by remember { mutableStateOf("0") }
    var hexSearchInput by remember { mutableStateOf("") }
    var hexSearchAsciiMode by remember { mutableStateOf(false) }
    var hexSearchMatches by remember { mutableStateOf<List<Long>>(emptyList()) }
    var hexPatchOffsetInput by remember { mutableStateOf("0") }
    var hexPatchBytesInput by remember { mutableStateOf("") }
    var hexStatusMessage by remember { mutableStateOf<String?>(null) }

    // Installed Apps & Task log state
    var installedApps by remember { mutableStateOf<List<InstalledAppItem>>(emptyList()) }
    var includeSystemApps by remember { mutableStateOf(false) }
    var appSearch by remember { mutableStateOf("") }
    var taskLog by remember { mutableStateOf<List<SessionTaskEntry>>(emptyList()) }

    fun recordTask(title: String, detail: String, succeeded: Boolean = true) {
        val entry = SessionTaskEntry(
            id = System.currentTimeMillis() + taskLog.size,
            title = title,
            detail = detail,
            succeeded = succeeded
        )
        taskLog = listOf(entry) + taskLog.take(99)
    }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            when (val result = storageRepo.persistSafTreePermission(uri)) {
                is AppResult.Success -> {
                    safStack = listOf(uri)
                    selectedIds = emptySet()
                    currentTab = TopDestination.FILES
                    statusBanner = "Folder access granted. Changes are limited to the folder you selected."
                }
                is AppResult.Error -> statusBanner = result.message
            }
        }
    }

    fun refreshDirectory() {
        scope.launch {
            val result = if (currentSafUri != null) {
                storageRepo.listSafDirectory(currentSafUri, includeHidden)
            } else {
                storageRepo.listDirectory(currentDir, includeHidden)
            }
            when (result) {
                is AppResult.Success -> {
                    files = result.data.sortedWith(
                        compareBy<FileNode>({ !it.isDirectory }, { it.name.lowercase(Locale.ROOT) })
                    )
                    selectedIds = selectedIds.intersect(files.map { it.id }.toSet())
                }
                is AppResult.Error -> {
                    files = emptyList()
                    statusBanner = result.message
                }
            }
        }
    }

    fun showResult(title: String, body: String) {
        reportTitle = title
        reportBody = body
        showReport = true
    }

    fun formatApkReport(a: ApkInspectionReport): String {
        val sb = StringBuilder()
        sb.appendLine("File: ${a.fileName}")
        sb.appendLine("Size: ${FileSizeFormatter.formatBytes(a.fileSizeBytes)}")
        sb.appendLine("SHA-256: ${a.sha256}")
        sb.appendLine("Archive entries: ${a.totalArchiveEntries} • resources.arsc: ${a.hasResourcesArsc}")
        sb.appendLine()

        val m = a.manifestSummary
        if (m != null) {
            sb.appendLine("=== AndroidManifest (${if (m.isBinaryAxml) "Decoded Binary AXML" else "XML"}) ===")
            sb.appendLine("Package: ${m.packageName}")
            sb.appendLine("Version: ${m.versionName} (code ${m.versionCode})")
            sb.appendLine("SDK: minSdk ${m.minSdk} • targetSdk ${m.targetSdk}")
            sb.appendLine("Permissions (${m.permissions.size}): ${m.permissions.take(15).joinToString(", ").ifBlank { "None" }}")
            sb.appendLine(
                "Components: ${m.activities.size} activities, ${m.services.size} services, " +
                    "${m.receivers.size} receivers, ${m.providers.size} providers"
            )
            if (m.decodedXmlPreview.isNotBlank()) {
                sb.appendLine("\nManifest XML preview:")
                sb.appendLine(m.decodedXmlPreview.take(1200))
            }
            sb.appendLine()
        }

        val sig = a.signatureSummary
        sb.appendLine("=== Signing & Certificates ===")
        sb.appendLine(
            "APK Signing Block: ${if (sig.hasApkSigBlock) "Present" else "Not found"} " +
                "(v2: ${sig.hasV2SchemeBlock}, v3: ${sig.hasV3SchemeBlock})"
        )
        sb.appendLine("v1 META-INF entries: ${sig.v1SignatureEntries.joinToString(", ").ifBlank { "None" }}")
        if (sig.certificates.isNotEmpty()) {
            sig.certificates.forEachIndexed { idx, cert ->
                sb.appendLine("Certificate #${idx + 1} (${cert.entryName}):")
                sb.appendLine("  Subject: ${cert.subjectDn}")
                sb.appendLine("  Issuer: ${cert.issuerDn}")
                sb.appendLine("  Algorithm: ${cert.sigAlgName} • Serial: ${cert.serialNumberHex}")
                sb.appendLine("  SHA-256 Cert: ${cert.sha256Fingerprint}")
                sb.appendLine("  Validity: ${cert.validFrom} → ${cert.validUntil}")
            }
        } else {
            sb.appendLine("Parsed X.509 certificates: None (or non-standard/synthetic block)")
        }
        sb.appendLine()

        sb.appendLine("=== DEX Headers (${a.dexFiles.size}) ===")
        if (a.dexFiles.isEmpty()) {
            sb.appendLine("None found")
        } else {
            a.dexFiles.forEach { d ->
                sb.appendLine(
                    "${d.entryName}: v${d.dexVersion}, ${d.classDefsSize} classes, " +
                        "${d.methodIdsSize} methods, ${d.fieldIdsSize} fields, ${d.stringIdsSize} strings"
                )
            }
        }
        sb.appendLine()
        sb.appendLine("=== Native Libraries (${a.nativeLibraries.size}) ===")
        sb.appendLine(a.nativeLibraries.take(30).joinToString("\n").ifBlank { "None" })
        return sb.toString()
    }

    fun localFileFor(node: FileNode): File? = if (!node.pathOrUri.startsWith("content://")) File(node.pathOrUri) else null

    fun openHexViewerFor(file: File, title: String, safUri: Uri?) {
        when (val r = hexReader.readChunk(file, 0L, 512)) {
            is AppResult.Success -> {
                hexWorkingFile = file
                hexOriginSafUri = safUri
                hexTitle = title
                hexPage = r.data
                hexOffsetInput = "0"
                hexPatchOffsetInput = "0"
                hexPatchBytesInput = ""
                hexSearchMatches = emptyList()
                hexStatusMessage = null
                showHexDialog = true
            }
            is AppResult.Error -> {
                if (safUri != null) file.delete()
                statusBanner = r.message
            }
        }
    }

    fun performAction(action: FileAction, node: FileNode) {
        selectedNode = node
        scope.launch {
            busy = true
            try {
                if (action == FileAction.RENAME) {
                    nameInput = node.name
                    showRenameDialog = true
                    return@launch
                }
                if (action == FileAction.DELETE) {
                    reportTitle = "Confirm deletion"
                    reportBody = "Delete ${node.name}? This cannot be undone."
                    showReport = true
                    return@launch
                }
                val localFile = localFileFor(node)
                val tempResult: AppResult<File> = if (localFile == null) {
                    withContext(Dispatchers.IO) {
                        storageRepo.copySafDocumentToCache(Uri.parse(node.pathOrUri), node.name)
                    }
                } else {
                    AppResult.Success(localFile)
                }
                when (tempResult) {
                    is AppResult.Error -> statusBanner = tempResult.message
                    is AppResult.Success -> {
                        val file = tempResult.data
                        when (action) {
                            FileAction.CHECKSUM -> when (val r = withContext(Dispatchers.IO) { fileOps.computeChecksums(file) }) {
                                is AppResult.Success -> showResult(
                                    "Checksums • ${node.name}",
                                    "SHA-256\n${r.data.sha256}\n\nMD5\n${r.data.md5}\n\nSize: ${FileSizeFormatter.formatBytes(r.data.sizeBytes)}"
                                )
                                is AppResult.Error -> statusBanner = r.message
                            }
                            FileAction.APK -> when (val r = withContext(Dispatchers.IO) { apkEngine.inspectApkArchive(file) }) {
                                is AppResult.Success -> showResult("APK inspection • ${node.name}", formatApkReport(r.data))
                                is AppResult.Error -> statusBanner = r.message
                            }
                            FileAction.ZIP_EXTRACT_WORKSPACE -> {
                                val destination = File(workspaceRoot, "Extracted_${System.currentTimeMillis()}").apply { mkdirs() }
                                when (val r = withContext(Dispatchers.IO) { zipEngine.extractArchive(file, destination) }) {
                                    is AppResult.Success -> {
                                        recordTask("ZIP Extraction", "Extracted ${r.data} files from ${node.name} to ${destination.name}")
                                        showResult("ZIP extraction complete", "Extracted ${r.data} files into app Workspace:\n${destination.absolutePath}")
                                        refreshDirectory()
                                    }
                                    is AppResult.Error -> {
                                        recordTask("ZIP Extraction Failed", r.message, succeeded = false)
                                        statusBanner = r.message
                                    }
                                }
                            }
                            FileAction.ZIP_EXTRACT_CURRENT -> {
                                if (currentSafUri != null) {
                                    val stagingDir = File(context.cacheDir, "zip_extract_${System.currentTimeMillis()}").apply { mkdirs() }
                                    try {
                                        when (val extRes = withContext(Dispatchers.IO) { zipEngine.extractArchive(file, stagingDir) }) {
                                            is AppResult.Error -> {
                                                recordTask("SAF ZIP Extraction Failed", extRes.message, succeeded = false)
                                                statusBanner = extRes.message
                                            }
                                            is AppResult.Success -> {
                                                val subFolderName = node.name.substringBeforeLast('.', node.name) + "_extracted"
                                                when (val folderRes = storageRepo.createSafDirectory(currentSafUri, subFolderName)) {
                                                    is AppResult.Error -> statusBanner = folderRes.message
                                                    is AppResult.Success -> {
                                                        when (val copyRes = storageRepo.copyDirectoryContentsToSaf(stagingDir, folderRes.data)) {
                                                            is AppResult.Success -> {
                                                                recordTask("SAF ZIP Extraction", "Extracted ${copyRes.data} files to SAF folder $subFolderName")
                                                                statusBanner = "Extracted ${copyRes.data} files to SAF folder $subFolderName."
                                                                refreshDirectory()
                                                            }
                                                            is AppResult.Error -> statusBanner = copyRes.message
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    } finally {
                                        stagingDir.deleteRecursively()
                                    }
                                } else {
                                    val targetDir = File(currentDir, node.name.substringBeforeLast('.', node.name) + "_extracted")
                                    when (val r = withContext(Dispatchers.IO) { zipEngine.extractArchive(file, targetDir) }) {
                                        is AppResult.Success -> {
                                            recordTask("ZIP Extraction", "Extracted ${r.data} files to ${targetDir.name}")
                                            statusBanner = "Extracted ${r.data} files into ${targetDir.name}."
                                            refreshDirectory()
                                        }
                                        is AppResult.Error -> statusBanner = r.message
                                    }
                                }
                            }
                            FileAction.ZIP -> when (val r = withContext(Dispatchers.IO) { zipEngine.listEntries(file) }) {
                                is AppResult.Success -> showResult(
                                    "ZIP contents • ${node.name}",
                                    r.data.take(500).joinToString("\n") { e ->
                                        "${if (e.isDirectory) "[DIR] " else ""}${e.path}  (${FileSizeFormatter.formatBytes(e.uncompressedSize)})${if (e.isSuspiciousTraversal) "  ⚠ unsafe path" else ""}"
                                    } + if (r.data.size > 500) "\n… ${r.data.size - 500} more entries" else ""
                                )
                                is AppResult.Error -> statusBanner = r.message
                            }
                            FileAction.HEX -> {
                                openHexViewerFor(
                                    file = file,
                                    title = node.name,
                                    safUri = if (localFile == null) Uri.parse(node.pathOrUri) else null
                                )
                            }
                            FileAction.TEXT -> when (val r = withContext(Dispatchers.IO) { textEngine.openDocument(file) }) {
                                is AppResult.Success -> {
                                    editorState = r.data
                                    editorTitle = node.name
                                    editorFile = localFile ?: file
                                    editorUri = if (localFile == null) Uri.parse(node.pathOrUri) else null
                                    editorMatchSummary = null
                                    showEditor = true
                                }
                                is AppResult.Error -> {
                                    if (localFile == null) file.delete()
                                    statusBanner = r.message
                                }
                            }
                            FileAction.RENAME -> {
                                nameInput = node.name
                                showRenameDialog = true
                            }
                            FileAction.DELETE -> {
                                reportTitle = "Delete ${node.name}?"
                                reportBody = "This permanently deletes the selected item. This cannot be undone."
                                showReport = true
                            }
                            FileAction.COPY_TO_WORKSPACE -> {
                                when (val r = storageRepo.copyOrMoveNodes(listOf(node), workspaceRoot, null, move = false, conflictPolicy = conflictPolicy)) {
                                    is AppResult.Success -> {
                                        recordTask("Copy to Workspace", "Copied ${node.name} to Workspace")
                                        statusBanner = "Copied ${node.name} to app Workspace."
                                    }
                                    is AppResult.Error -> statusBanner = r.message
                                }
                            }
                        }
                        if (localFile == null && action != FileAction.TEXT && action != FileAction.HEX) {
                            file.delete()
                        }
                    }
                }
            } catch (e: Exception) {
                statusBanner = "Action failed: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                busy = false
            }
        }
    }

    LaunchedEffect(currentDir, currentSafUri, includeHidden) { refreshDirectory() }

    val selectedNodes = remember(files, selectedIds) {
        files.filter { it.id in selectedIds }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("DroidForge", fontWeight = FontWeight.Bold)
                        Text(
                            if (multiSelectMode && selectedIds.isNotEmpty()) "${selectedIds.size} selected" else currentTab.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    if (currentTab == TopDestination.FILES) {
                        IconButton(onClick = {
                            multiSelectMode = !multiSelectMode
                            if (!multiSelectMode) selectedIds = emptySet()
                        }) {
                            Icon(
                                if (multiSelectMode) Icons.Default.Close else Icons.Default.CheckBox,
                                contentDescription = "Toggle multi-select mode"
                            )
                        }
                        IconButton(onClick = { folderPicker.launch(null) }) {
                            Icon(Icons.Default.FolderOpen, contentDescription = "Choose storage folder")
                        }
                        IconButton(onClick = { showFolderDialog = true }) {
                            Icon(Icons.Default.CreateNewFolder, contentDescription = "Create folder")
                        }
                    }
                    IconButton(onClick = { showOnboarding = true }) {
                        Icon(Icons.Default.Info, contentDescription = "Storage information")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                TopDestination.entries.forEach { dest ->
                    NavigationBarItem(
                        selected = currentTab == dest,
                        onClick = { currentTab = dest },
                        icon = {
                            Icon(
                                when (dest) {
                                    TopDestination.HOME -> Icons.Default.Home
                                    TopDestination.FILES -> Icons.Default.Folder
                                    TopDestination.APPS -> Icons.Default.Apps
                                    TopDestination.TOOLS -> Icons.Default.Build
                                    TopDestination.TASKS -> Icons.Default.Checklist
                                    TopDestination.SETTINGS -> Icons.Default.Settings
                                },
                                contentDescription = dest.label
                            )
                        },
                        label = { Text(dest.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            statusBanner?.let { msg ->
                Card(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(msg, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { statusBanner = null }) { Text("Dismiss") }
                    }
                }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(bottom = 8.dp))

            when (currentTab) {
                TopDestination.HOME -> {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        Text("Welcome to DroidForge", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Offline-first Android file manager, binary/text editor, and APK/AXML inspector.", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { safStack = emptyList(); currentTab = TopDestination.FILES }) {
                                Icon(Icons.Default.Folder, null)
                                Spacer(Modifier.width(6.dp))
                                Text("Open Workspace")
                            }
                            OutlinedButton(onClick = { folderPicker.launch(null) }) {
                                Icon(Icons.Default.FolderOpen, null)
                                Spacer(Modifier.width(6.dp))
                                Text("Add SAF Folder")
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Text("Accessible storage roots", style = MaterialTheme.typography.titleMedium)
                        storageRepo.getAccessibleLocations().forEach { loc ->
                            Card(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        if (loc.isSafTree) {
                                            safStack = listOf(Uri.parse(loc.uriOrPath))
                                        } else {
                                            safStack = emptyList()
                                            currentDir = workspaceRoot
                                        }
                                        currentTab = TopDestination.FILES
                                    }
                            ) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(loc.label, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        if (loc.isSafTree) "SAF Tree • permission ${if (loc.permissionGranted) "active" else "revoked"} (tap to browse)"
                                        else "App-private Workspace • ${FileSizeFormatter.formatBytes(loc.freeBytes)} free on volume",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                }

                TopDestination.FILES -> {
                    // Navigation header
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            enabled = if (currentSafUri != null) safStack.size > 1 else currentDir.absolutePath != context.filesDir.absolutePath,
                            onClick = {
                                if (currentSafUri != null) safStack = safStack.dropLast(1)
                                else currentDir.parentFile?.let { currentDir = it }
                            }
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Up")
                        }
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(if (currentSafUri != null) "Selected SAF Folder" else "App Workspace", style = MaterialTheme.typography.labelMedium)
                                if (currentSafUri != null) {
                                    TextButton(
                                        onClick = { safStack = emptyList() },
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                                    ) { Text("Switch to Workspace", style = MaterialTheme.typography.labelSmall) }
                                }
                            }
                            Text(
                                if (currentSafUri != null) DocumentFile.fromTreeUri(context, currentSafUri)?.name ?: currentSafUri.lastPathSegment.orEmpty()
                                else currentDir.absolutePath,
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 1
                            )
                        }
                        TextButton(onClick = { includeHidden = !includeHidden }) {
                            Text(if (includeHidden) "Hide ." else "Show .")
                        }
                    }

                    // Multi-select batch action bar
                    if (multiSelectMode) {
                        Card(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                        ) {
                            Column(Modifier.padding(8.dp)) {
                                Row(
                                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextButton(onClick = { selectedIds = files.map { it.id }.toSet() }) { Text("All (${files.size})") }
                                    TextButton(onClick = { selectedIds = emptySet() }) { Text("None") }
                                    Button(
                                        enabled = selectedNodes.isNotEmpty(),
                                        onClick = {
                                            clipboardNodes = selectedNodes
                                            clipboardIsMove = false
                                            multiSelectMode = false
                                            selectedIds = emptySet()
                                            statusBanner = "${clipboardNodes.size} item(s) copied to clipboard. Open destination folder and tap Paste."
                                        }
                                    ) { Text("Copy") }
                                    Button(
                                        enabled = selectedNodes.isNotEmpty(),
                                        onClick = {
                                            clipboardNodes = selectedNodes
                                            clipboardIsMove = true
                                            multiSelectMode = false
                                            selectedIds = emptySet()
                                            statusBanner = "${clipboardNodes.size} item(s) marked for move. Open destination folder and tap Paste."
                                        }
                                    ) { Text("Cut") }
                                    OutlinedButton(
                                        enabled = selectedNodes.isNotEmpty(),
                                        onClick = {
                                            batchPrefix = ""
                                            batchSuffix = ""
                                            batchFind = ""
                                            batchReplace = ""
                                            batchUseNumbering = false
                                            showBatchRenameDialog = true
                                        }
                                    ) { Text("Batch Rename") }
                                    OutlinedButton(
                                        enabled = selectedNodes.isNotEmpty(),
                                        onClick = {
                                            zipArchiveName = "archive_${System.currentTimeMillis() / 1000}.zip"
                                            showCreateZipDialog = true
                                        }
                                    ) { Text("ZIP") }
                                    OutlinedButton(
                                        enabled = selectedNodes.isNotEmpty(),
                                        onClick = {
                                            scope.launch {
                                                busy = true
                                                var delCount = 0
                                                for (n in selectedNodes) {
                                                    val ok = if (n.pathOrUri.startsWith("content://")) {
                                                        storageRepo.deleteSafDocument(Uri.parse(n.pathOrUri)) is AppResult.Success
                                                    } else {
                                                        File(n.pathOrUri).deleteRecursively()
                                                    }
                                                    if (ok) delCount++
                                                }
                                                busy = false
                                                recordTask("Batch Delete", "Deleted $delCount of ${selectedNodes.size} selected items")
                                                statusBanner = "Deleted $delCount item(s)."
                                                selectedIds = emptySet()
                                                multiSelectMode = false
                                                refreshDirectory()
                                            }
                                        }
                                    ) { Text("Delete", color = MaterialTheme.colorScheme.error) }
                                }
                            }
                        }
                    }

                    // Clipboard Paste bar (works across Workspace and SAF)
                    if (clipboardNodes.isNotEmpty()) {
                        Card(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
                        ) {
                            Row(
                                Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    "${clipboardNodes.size} item(s) to ${if (clipboardIsMove) "move" else "copy"}",
                                    Modifier.weight(1f),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                TextButton(onClick = {
                                    conflictPolicy = when (conflictPolicy) {
                                        ConflictPolicy.KEEP_BOTH -> ConflictPolicy.REPLACE
                                        ConflictPolicy.REPLACE -> ConflictPolicy.SKIP
                                        ConflictPolicy.SKIP -> ConflictPolicy.KEEP_BOTH
                                    }
                                }) {
                                    Text("Conflict: ${conflictPolicy.name}")
                                }
                                Button(onClick = {
                                    scope.launch {
                                        busy = true
                                        val res = storageRepo.copyOrMoveNodes(
                                            sources = clipboardNodes,
                                            destWorkspaceDir = if (currentSafUri == null) currentDir else null,
                                            destSafDirUri = currentSafUri,
                                            move = clipboardIsMove,
                                            conflictPolicy = conflictPolicy
                                        )
                                        busy = false
                                        when (res) {
                                            is AppResult.Success -> {
                                                val r = res.data
                                                val opName = if (clipboardIsMove) "Move" else "Copy"
                                                recordTask(
                                                    "$opName Complete",
                                                    "Succeeded: ${r.succeededCount}, Skipped: ${r.skippedCount}, Failed: ${r.failedItems.size}",
                                                    succeeded = r.failedItems.isEmpty()
                                                )
                                                statusBanner = "$opName complete: ${r.succeededCount} succeeded, ${r.skippedCount} skipped, ${r.failedItems.size} failed."
                                                clipboardNodes = emptyList()
                                                refreshDirectory()
                                            }
                                            is AppResult.Error -> {
                                                recordTask("Clipboard Transfer Failed", res.message, succeeded = false)
                                                statusBanner = res.message
                                            }
                                        }
                                    }
                                }) { Text("Paste Here") }
                                IconButton(onClick = { clipboardNodes = emptyList() }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear clipboard")
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Filter this folder") },
                        leadingIcon = { Icon(Icons.Default.Search, null) }
                    )

                    val shownFiles = files.filter { it.name.contains(searchQuery, ignoreCase = true) }
                    if (shownFiles.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(if (files.isEmpty()) "This folder is empty or unavailable." else "No matching files.")
                        }
                    } else {
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(shownFiles, key = { it.id }) { node ->
                                val isChecked = node.id in selectedIds
                                ListItem(
                                    headlineContent = { Text(node.name, maxLines = 1) },
                                    supportingContent = {
                                        Text(
                                            if (node.isDirectory) "Folder"
                                            else "${FileSizeFormatter.formatBytes(node.sizeBytes)} • ${node.mimeType}",
                                            maxLines = 1
                                        )
                                    },
                                    leadingContent = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (multiSelectMode) {
                                                Checkbox(
                                                    checked = isChecked,
                                                    onCheckedChange = { checked ->
                                                        selectedIds = if (checked) selectedIds + node.id else selectedIds - node.id
                                                    }
                                                )
                                            }
                                            Icon(
                                                if (node.isDirectory) Icons.Default.Folder else Icons.Default.InsertDriveFile,
                                                contentDescription = null
                                            )
                                        }
                                    },
                                    trailingContent = {
                                        IconButton(onClick = {
                                            selectedNode = node
                                            reportTitle = "Actions • ${node.name}"
                                            reportBody = "Choose an action below."
                                            showReport = true
                                        }) {
                                            Icon(Icons.Default.MoreVert, contentDescription = "File actions")
                                        }
                                    },
                                    modifier = Modifier.clickable {
                                        if (multiSelectMode) {
                                            selectedIds = if (isChecked) selectedIds - node.id else selectedIds + node.id
                                        } else if (node.isDirectory) {
                                            if (currentSafUri != null) safStack = safStack + Uri.parse(node.pathOrUri)
                                            else currentDir = File(node.pathOrUri)
                                        } else {
                                            selectedNode = node
                                            reportTitle = node.name
                                            reportBody = "${FileSizeFormatter.formatBytes(node.sizeBytes)} • ${node.mimeType}\nChoose an action."
                                            showReport = true
                                        }
                                    }
                                )
                                HorizontalDivider()
                            }
                        }
                    }
                }

                TopDestination.APPS -> {
                    LaunchedEffect(includeSystemApps) {
                        when (val result = appsRepo.loadInstalledApps(includeSystemApps)) {
                            is AppResult.Success -> installedApps = result.data
                            is AppResult.Error -> statusBanner = result.message
                        }
                    }
                    Text("Installed apps", style = MaterialTheme.typography.titleLarge)
                    Text("Inspect installed APK manifests/certificates, back up base APKs to Workspace, or open system App Info.", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = appSearch,
                        onValueChange = { appSearch = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Search apps or package names") },
                        singleLine = true
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Include system apps", Modifier.weight(1f))
                        Switch(checked = includeSystemApps, onCheckedChange = { includeSystemApps = it })
                    }
                    val visibleApps = installedApps.filter {
                        it.appName.contains(appSearch, true) || it.packageName.contains(appSearch, true)
                    }
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(visibleApps, key = { it.packageName }) { app ->
                            ListItem(
                                headlineContent = { Text(app.appName) },
                                supportingContent = {
                                    Text(
                                        "${app.packageName}\nVersion ${app.versionName} (${app.versionCode}) • ${FileSizeFormatter.formatBytes(app.apkSizeBytes)}",
                                        maxLines = 3
                                    )
                                },
                                leadingContent = { Icon(Icons.Default.Android, null) },
                                trailingContent = {
                                    Row {
                                        TextButton(onClick = {
                                            scope.launch {
                                                busy = true
                                                when (val r = appsRepo.backupApkToWorkspace(app, workspaceRoot)) {
                                                    is AppResult.Success -> {
                                                        recordTask("APK Backup", "Backed up ${app.packageName} to ${r.data.name}")
                                                        statusBanner = "Backed up APK to Workspace/APKs/${r.data.name}"
                                                    }
                                                    is AppResult.Error -> statusBanner = r.message
                                                }
                                                busy = false
                                            }
                                        }) { Text("Backup") }
                                        TextButton(onClick = {
                                            scope.launch {
                                                busy = true
                                                val apkFile = File(app.sourceApkPath)
                                                val inspectText = if (apkFile.exists() && apkFile.canRead()) {
                                                    when (val r = withContext(Dispatchers.IO) { apkEngine.inspectApkArchive(apkFile) }) {
                                                        is AppResult.Success -> "\n\n" + formatApkReport(r.data)
                                                        is AppResult.Error -> "\n\nAPK archive inspection: ${r.message}"
                                                    }
                                                } else ""
                                                busy = false
                                                showResult(
                                                    app.appName,
                                                    "Package: ${app.packageName}\nVersion: ${app.versionName} (${app.versionCode})\n" +
                                                        "Min SDK: ${app.minSdk} • Target SDK: ${app.targetSdk}\n" +
                                                        "System app: ${app.isSystemApp}\n" +
                                                        "Source APK: ${app.sourceApkPath}\n" +
                                                        "APK size: ${FileSizeFormatter.formatBytes(app.apkSizeBytes)}\n" +
                                                        "Requested permissions (${app.requestedPermissions.size}):\n" +
                                                        app.requestedPermissions.take(25).joinToString("\n").ifBlank { "None" } +
                                                        inspectText
                                                )
                                            }
                                        }) { Text("Inspect") }
                                        IconButton(onClick = { appsRepo.openSystemAppDetails(app.packageName) }) {
                                            Icon(Icons.Default.Settings, contentDescription = "System App Info")
                                        }
                                    }
                                }
                            )
                            HorizontalDivider()
                        }
                    }
                }

                TopDestination.TOOLS -> {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        Text("File & APK Tools", style = MaterialTheme.typography.titleLarge)
                        Text("Run standalone Workspace utilities or select any file in Files for inspection and editing.")
                        Spacer(Modifier.height(8.dp))
                        ToolRow("Multi-select, Cross-SAF Copy/Move & Batch Rename", "Tap the checkbox icon in Files to select multiple items, copy/cut across Workspace and SAF folders, or batch rename with collision checks.")
                        ToolRow("Binary AXML & Certificate APK Inspector", "Select any .apk file (or tap Inspect in Apps) to decode binary AndroidManifest.xml, inspect v1/v2/v3 signing blocks & X.509 certificates, and read DEX headers.")
                        ToolRow("Interactive Hex Viewer & Byte Patcher", "Select any file → Hex viewer to paginate 512-byte chunks, jump to offsets, search hex/ASCII bytes, and patch bytes in place.")
                        ToolRow("Text Editor with Undo/Redo & Regex Replace", "Select a text/code file → Open as text for undo/redo history, line/word/byte stats, and ReDoS-guarded find & replace.")
                        ToolRow("ZIP Creation & Direct SAF Extraction", "Select items in Files → ZIP to create an archive, or tap a .zip file to extract to Workspace or the active SAF folder.")
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                scope.launch {
                                    busy = true
                                    when (val r = withContext(Dispatchers.IO) { fileOps.findDuplicateFiles(workspaceRoot) }) {
                                        is AppResult.Success -> {
                                            val groups = r.data
                                            val body = if (groups.isEmpty()) {
                                                "No duplicate files found inside App Workspace."
                                            } else {
                                                groups.entries.joinToString("\n\n") { (key, list) ->
                                                    "SHA-256 group ($key):\n" + list.joinToString("\n") { " • ${it.relativeTo(workspaceRoot).path}" }
                                                }
                                            }
                                            recordTask("Duplicate Scan", "Found ${groups.size} duplicate group(s) in Workspace")
                                            showResult("Workspace Duplicate Finder", body)
                                        }
                                        is AppResult.Error -> statusBanner = r.message
                                    }
                                    busy = false
                                }
                            }) { Text("Scan Workspace Duplicates") }
                            OutlinedButton(onClick = { currentTab = TopDestination.FILES }) { Text("Go to Files") }
                        }
                    }
                }

                TopDestination.TASKS -> {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Session Tasks (${taskLog.size})", style = MaterialTheme.typography.titleLarge, Modifier.weight(1f))
                        if (taskLog.isNotEmpty()) {
                            TextButton(onClick = { taskLog = emptyList() }) { Text("Clear") }
                        }
                    }
                    if (taskLog.isEmpty()) {
                        Text(
                            "Completed file transfers, batch renames, ZIP creations/extractions, APK backups, and binary patches appear here.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    } else {
                        val fmt = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(taskLog, key = { it.id }) { item ->
                                ListItem(
                                    headlineContent = { Text(item.title, fontWeight = FontWeight.SemiBold) },
                                    supportingContent = { Text("${fmt.format(Date(item.timestampMillis))} • ${item.detail}") },
                                    leadingContent = {
                                        Icon(
                                            if (item.succeeded) Icons.Default.CheckCircle else Icons.Default.Error,
                                            contentDescription = null,
                                            tint = if (item.succeeded) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                        )
                                    }
                                )
                                HorizontalDivider()
                            }
                        }
                    }
                }

                TopDestination.SETTINGS -> {
                    Text("Settings", style = MaterialTheme.typography.titleLarge)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Show hidden files (dotfiles)", Modifier.weight(1f))
                        Switch(checked = includeHidden, onCheckedChange = { includeHidden = it })
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Default conflict resolution policy for Copy/Move:",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ConflictPolicy.entries.forEach { pol ->
                            FilterChip(
                                selected = conflictPolicy == pol,
                                onClick = { conflictPolicy = pol },
                                label = { Text(pol.name) }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Storage access is granted per folder through Android's system picker. DroidForge does not bypass Android's scoped-storage restrictions.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedButton(onClick = { showOnboarding = true }) { Text("Storage and privacy details") }
                }
            }
        }
    }

    // Batch Rename Dialog
    if (showBatchRenameDialog) {
        val previewItems = remember(selectedNodes, files, batchPrefix, batchSuffix, batchFind, batchReplace, batchUseNumbering) {
            val entries = selectedNodes.map { Triple(File(it.pathOrUri), it.name, it.isDirectory) }
            val existingNames = files.map { it.name }.toSet()
            fileOps.previewBatchRenameNamedEntries(
                entries = entries,
                existingSiblingNames = existingNames,
                prefix = batchPrefix,
                suffix = batchSuffix,
                findText = batchFind,
                replaceText = batchReplace,
                startNumber = if (batchUseNumbering) 1 else null
            )
        }
        val hasCollisions = previewItems.any { it.hasCollision }

        AlertDialog(
            onDismissRequest = { showBatchRenameDialog = false },
            title = { Text("Batch Rename (${selectedNodes.size} items)") },
            text = {
                Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = batchPrefix, onValueChange = { batchPrefix = it }, label = { Text("Prefix") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = batchSuffix, onValueChange = { batchSuffix = it }, label = { Text("Suffix") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = batchFind, onValueChange = { batchFind = it }, label = { Text("Find") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = batchReplace, onValueChange = { batchReplace = it }, label = { Text("Replace") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = batchUseNumbering, onCheckedChange = { batchUseNumbering = it })
                        Text("Append sequence numbers (_01, _02…)", style = MaterialTheme.typography.bodySmall)
                    }
                    HorizontalDivider(Modifier.padding(vertical = 6.dp))
                    Text("Live Preview:", style = MaterialTheme.typography.labelMedium)
                    previewItems.take(15).forEach { item ->
                        Text(
                            "${item.originalName} → ${item.proposedName}" + (item.collisionReason?.let { " [$it]" } ?: ""),
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = if (item.hasCollision) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !hasCollisions && previewItems.isNotEmpty(),
                    onClick = {
                        scope.launch {
                            busy = true
                            if (currentSafUri == null) {
                                when (val r = withContext(Dispatchers.IO) { fileOps.applyBatchRename(previewItems) }) {
                                    is AppResult.Success -> {
                                        recordTask("Batch Rename", "Renamed ${r.data} item(s) in Workspace")
                                        statusBanner = "Batch renamed ${r.data} item(s)."
                                    }
                                    is AppResult.Error -> statusBanner = r.message
                                }
                            } else {
                                var count = 0
                                for (item in previewItems) {
                                    if (item.originalName != item.proposedName) {
                                        val res = storageRepo.renameSafDocument(Uri.parse(item.sourceIdOrUri), item.proposedName)
                                        if (res is AppResult.Success) count++
                                    }
                                }
                                recordTask("SAF Batch Rename", "Renamed $count item(s) in SAF folder")
                                statusBanner = "Batch renamed $count item(s) in SAF folder."
                            }
                            busy = false
                            showBatchRenameDialog = false
                            multiSelectMode = false
                            selectedIds = emptySet()
                            refreshDirectory()
                        }
                    }
                ) { Text("Apply Rename") }
            },
            dismissButton = {
                TextButton(onClick = { showBatchRenameDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Create ZIP Dialog
    if (showCreateZipDialog) {
        AlertDialog(
            onDismissRequest = { showCreateZipDialog = false },
            title = { Text("Create ZIP Archive (${selectedNodes.size} items)") },
            text = {
                Column {
                    OutlinedTextField(
                        value = zipArchiveName,
                        onValueChange = { zipArchiveName = it },
                        label = { Text("Archive file name (.zip)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (currentSafUri == null) "Archive will be saved in the current Workspace folder."
                        else "Archive will be created and saved in both the current SAF folder and Workspace/Archives.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val cleanName = zipArchiveName.trim().let { if (it.endsWith(".zip", true)) it else "$it.zip" }
                    scope.launch {
                        busy = true
                        val tempStaging = File(context.cacheDir, "zip_stage_${System.currentTimeMillis()}").apply { mkdirs() }
                        try {
                            val localSources = if (currentSafUri == null) {
                                selectedNodes.map { File(it.pathOrUri) }
                            } else {
                                storageRepo.copyOrMoveNodes(selectedNodes, tempStaging, null, move = false)
                                tempStaging.listFiles()?.toList().orEmpty()
                            }
                            val targetZip = if (currentSafUri == null) {
                                File(currentDir, cleanName)
                            } else {
                                File(File(workspaceRoot, "Archives").apply { mkdirs() }, cleanName)
                            }
                            when (val r = withContext(Dispatchers.IO) { zipEngine.createZipArchive(localSources, targetZip) }) {
                                is AppResult.Success -> {
                                    if (currentSafUri != null) {
                                        val zipNode = FileNode(
                                            id = targetZip.absolutePath,
                                            name = targetZip.name,
                                            pathOrUri = targetZip.absolutePath,
                                            isDirectory = false,
                                            sizeBytes = targetZip.length(),
                                            lastModifiedMillis = targetZip.lastModified(),
                                            mimeType = "application/zip"
                                        )
                                        storageRepo.copyOrMoveNodes(listOf(zipNode), null, currentSafUri, move = false)
                                    }
                                    recordTask("ZIP Created", "Created $cleanName (${FileSizeFormatter.formatBytes(r.data)})")
                                    statusBanner = "Created $cleanName (${FileSizeFormatter.formatBytes(r.data)})."
                                    refreshDirectory()
                                }
                                is AppResult.Error -> statusBanner = r.message
                            }
                        } finally {
                            tempStaging.deleteRecursively()
                            busy = false
                            showCreateZipDialog = false
                            multiSelectMode = false
                            selectedIds = emptySet()
                        }
                    }
                }) { Text("Create ZIP") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateZipDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showFolderDialog) {
        AlertDialog(
            onDismissRequest = { showFolderDialog = false; nameInput = "" },
            title = { Text("Create folder") },
            text = { OutlinedTextField(value = nameInput, onValueChange = { nameInput = it }, label = { Text("Folder name") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val name = nameInput.trim()
                    if (name.isNotEmpty()) {
                        if (currentSafUri != null) {
                            when (val r = storageRepo.createSafDirectory(currentSafUri, name)) {
                                is AppResult.Success -> { statusBanner = "Created folder $name"; refreshDirectory() }
                                is AppResult.Error -> statusBanner = r.message
                            }
                        } else {
                            val dir = File(currentDir, name)
                            statusBanner = if (dir.mkdir()) "Created folder $name" else "Could not create folder. Check the name and permissions."
                            refreshDirectory()
                        }
                    }
                    showFolderDialog = false
                    nameInput = ""
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showFolderDialog = false }) { Text("Cancel") } }
        )
    }

    if (showRenameDialog) {
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("Rename item") },
            text = { OutlinedTextField(value = nameInput, onValueChange = { nameInput = it }, label = { Text("New name") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val node = selectedNode
                    if (node != null && nameInput.isNotBlank()) {
                        if (currentSafUri != null) {
                            when (val r = storageRepo.renameSafDocument(Uri.parse(node.pathOrUri), nameInput)) {
                                is AppResult.Success -> statusBanner = "Renamed item"
                                is AppResult.Error -> statusBanner = r.message
                            }
                        } else {
                            val target = File(File(node.pathOrUri).parentFile, nameInput.trim())
                            statusBanner = if (target.exists()) "An item with that name already exists."
                            else if (File(node.pathOrUri).renameTo(target)) "Renamed item"
                            else "Rename failed."
                        }
                        refreshDirectory()
                    }
                    showRenameDialog = false
                }) { Text("Rename") }
            },
            dismissButton = { TextButton(onClick = { showRenameDialog = false }) { Text("Cancel") } }
        )
    }

    if (showReport) {
        val node = selectedNode
        val isActionSheet = (node != null && reportTitle.startsWith("Actions")) || (node != null && reportBody.contains("Choose an action"))
        AlertDialog(
            onDismissRequest = { showReport = false },
            title = { Text(reportTitle) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(reportBody, style = MaterialTheme.typography.bodySmall, fontFamily = if (isActionSheet) FontFamily.Default else FontFamily.Monospace)
                    if (isActionSheet && node != null) {
                        Spacer(Modifier.height(12.dp))
                        val ext = node.name.substringAfterLast('.', "").lowercase()
                        if (!node.isDirectory) {
                            ActionButton(
                                "Open in Text Editor (Undo/Redo & Find/Replace)",
                                enabled = ext in setOf("txt", "md", "log", "ini", "cfg", "json", "xml", "kt", "java", "py", "sh", "js", "css", "html", "csv", "gradle", "toml", "pro")
                            ) { showReport = false; performAction(FileAction.TEXT, node) }
                            ActionButton("Open in Interactive Hex Viewer / Patcher") { showReport = false; performAction(FileAction.HEX, node) }
                            ActionButton("Compute SHA-256 & MD5 Checksums") { showReport = false; performAction(FileAction.CHECKSUM, node) }
                            if (ext == "apk") {
                                ActionButton("Inspect APK (AXML Manifest, Certs & DEX)") { showReport = false; performAction(FileAction.APK, node) }
                            }
                            if (ext == "zip" || ext == "jar" || ext == "apk") {
                                ActionButton("Browse Archive Entries") { showReport = false; performAction(FileAction.ZIP, node) }
                                ActionButton("Extract Archive to Current Folder") { showReport = false; performAction(FileAction.ZIP_EXTRACT_CURRENT, node) }
                                ActionButton("Extract Archive to App Workspace") { showReport = false; performAction(FileAction.ZIP_EXTRACT_WORKSPACE, node) }
                            }
                            ActionButton("Copy to App Workspace") { showReport = false; performAction(FileAction.COPY_TO_WORKSPACE, node) }
                        }
                        ActionButton("Copy to Clipboard (for cross-folder Paste)") {
                            clipboardNodes = listOf(node)
                            clipboardIsMove = false
                            showReport = false
                            statusBanner = "Copied ${node.name} to clipboard."
                        }
                        ActionButton("Cut to Clipboard (Move)") {
                            clipboardNodes = listOf(node)
                            clipboardIsMove = true
                            showReport = false
                            statusBanner = "Marked ${node.name} for move."
                        }
                        HorizontalDivider(Modifier.padding(vertical = 6.dp))
                        ActionButton("Rename") { showReport = false; performAction(FileAction.RENAME, node) }
                        ActionButton("Delete permanently…", danger = true) {
                            showReport = false
                            reportTitle = "Confirm deletion"
                            reportBody = "Delete ${node.name}? This cannot be undone."
                            selectedNode = node
                            showReport = true
                        }
                    } else if (reportTitle == "Confirm deletion" && node != null) {
                        Text("This action cannot be undone.", color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                if (reportTitle == "Confirm deletion" && node != null) {
                    TextButton(onClick = {
                        if (currentSafUri != null) {
                            when (val r = storageRepo.deleteSafDocument(Uri.parse(node.pathOrUri))) {
                                is AppResult.Success -> statusBanner = "Deleted ${node.name}"
                                is AppResult.Error -> statusBanner = r.message
                            }
                        } else {
                            statusBanner = if (File(node.pathOrUri).deleteRecursively()) "Deleted ${node.name}" else "Delete failed."
                        }
                        showReport = false
                        refreshDirectory()
                    }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
                } else {
                    TextButton(onClick = { showReport = false }) { Text("Close") }
                }
            },
            dismissButton = {
                if (reportTitle == "Confirm deletion") {
                    TextButton(onClick = { showReport = false }) { Text("Cancel") }
                }
            }
        )
    }

    // Upgraded Text Editor with Undo/Redo & Find/Replace
    if (showEditor) {
        val currentState = editorState
        val textContent = currentState?.content.orEmpty()
        val stats = remember(textContent) { textEngine.computeStats(textContent) }

        AlertDialog(
            onDismissRequest = {
                if (currentState?.isDirty != true) {
                    showEditor = false
                    editorFile?.takeIf { editorUri != null }?.delete()
                } else {
                    statusBanner = "Editor has unsaved changes. Save or tap Close deliberately."
                }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(editorTitle, Modifier.weight(1f), maxLines = 1)
                    IconButton(
                        enabled = currentState?.canUndo == true,
                        onClick = { editorState = currentState?.let { textEngine.undo(it) } }
                    ) { Icon(Icons.Default.Undo, contentDescription = "Undo") }
                    IconButton(
                        enabled = currentState?.canRedo == true,
                        onClick = { editorState = currentState?.let { textEngine.redo(it) } }
                    ) { Icon(Icons.Default.Redo, contentDescription = "Redo") }
                    IconButton(onClick = { showFindReplaceBar = !showFindReplaceBar }) {
                        Icon(Icons.Default.FindReplace, contentDescription = "Find and Replace")
                    }
                }
            },
            text = {
                Column(Modifier.fillMaxWidth()) {
                    Text(
                        "${stats.lineCount} lines • ${stats.wordCount} words • ${stats.charCount} chars (${stats.byteCountUtf8} B) • ${currentState?.lineEndingStyle ?: "LF"}${if (currentState?.isReadOnly == true) " • READ-ONLY" else ""}",
                        style = MaterialTheme.typography.labelSmall
                    )
                    if (showFindReplaceBar) {
                        Spacer(Modifier.height(6.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                            Column(Modifier.padding(8.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedTextField(
                                        value = editorFindQuery,
                                        onValueChange = { editorFindQuery = it },
                                        label = { Text("Find") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = editorReplaceText,
                                        onValueChange = { editorReplaceText = it },
                                        label = { Text("Replace") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    FilterChip(
                                        selected = editorCaseSensitive,
                                        onClick = { editorCaseSensitive = !editorCaseSensitive },
                                        label = { Text("Aa") }
                                    )
                                    FilterChip(
                                        selected = editorUseRegex,
                                        onClick = { editorUseRegex = !editorUseRegex },
                                        label = { Text("Regex") }
                                    )
                                    TextButton(onClick = {
                                        when (val r = textEngine.safeFindMatches(textContent, editorFindQuery, editorUseRegex, editorCaseSensitive)) {
                                            is AppResult.Success -> {
                                                val first = r.data.firstOrNull()
                                                editorMatchSummary = if (first == null) "0 matches"
                                                else "${r.data.size} match(es) (first at char ${first.first})"
                                            }
                                            is AppResult.Error -> editorMatchSummary = r.message
                                        }
                                    }) { Text("Find") }
                                    TextButton(
                                        enabled = currentState != null && !currentState.isReadOnly,
                                        onClick = {
                                            if (currentState != null) {
                                                when (val r = textEngine.replaceAllMatches(currentState, editorFindQuery, editorReplaceText, editorUseRegex, editorCaseSensitive)) {
                                                    is AppResult.Success -> {
                                                        editorState = r.data.first
                                                        editorMatchSummary = "Replaced ${r.data.second} occurrence(s)"
                                                    }
                                                    is AppResult.Error -> editorMatchSummary = r.message
                                                }
                                            }
                                        }
                                    ) { Text("Replace All") }
                                }
                                editorMatchSummary?.let {
                                    Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = textContent,
                        onValueChange = { newText ->
                            if (currentState != null) {
                                editorState = textEngine.applyEdit(currentState, newText)
                            }
                        },
                        readOnly = currentState?.isReadOnly == true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 220.dp, max = 420.dp),
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = currentState?.isReadOnly != true,
                    onClick = {
                        scope.launch {
                            val uri = editorUri
                            val file = editorFile
                            val state = editorState
                            val result: AppResult<Unit> = if (uri != null && state != null) {
                                withContext(Dispatchers.IO) { storageRepo.writeTextToSafDocument(uri, state.content) }
                            } else if (file != null && state != null) {
                                when (val saved = withContext(Dispatchers.IO) { textEngine.saveDocument(state, file, forceOverwriteExternalChanges = true) }) {
                                    is AppResult.Success -> {
                                        editorState = saved.data
                                        AppResult.Success(Unit)
                                    }
                                    is AppResult.Error -> AppResult.Error(saved.message, saved.cause)
                                }
                            } else {
                                AppResult.Error("No save destination or editor state.")
                            }
                            when (result) {
                                is AppResult.Success -> {
                                    recordTask("Text Saved", "Saved changes to $editorTitle")
                                    showEditor = false
                                    editorFile?.takeIf { editorUri != null }?.delete()
                                    statusBanner = "Saved $editorTitle"
                                    refreshDirectory()
                                }
                                is AppResult.Error -> statusBanner = result.message
                            }
                        }
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = {
                    showEditor = false
                    editorFile?.takeIf { editorUri != null }?.delete()
                }) { Text("Close") }
            }
        )
    }

    // Interactive Hex Viewer & Byte Patcher Dialog
    if (showHexDialog) {
        val page = hexPage
        val workFile = hexWorkingFile
        AlertDialog(
            onDismissRequest = {
                showHexDialog = false
                if (hexOriginSafUri != null) workFile?.delete()
            },
            title = { Text("Hex Viewer & Patcher • $hexTitle") },
            text = {
                Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                    if (page != null && workFile != null) {
                        Text(
                            "File size: ${FileSizeFormatter.formatBytes(page.totalFileSize)} (${page.totalFileSize} B) • Showing offset 0x${page.fileOffset.toString(16).uppercase()}",
                            style = MaterialTheme.typography.labelSmall
                        )
                        Spacer(Modifier.height(6.dp))
                        // Offset navigation controls
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedButton(
                                enabled = page.fileOffset > 0L,
                                onClick = {
                                    val prev = (page.fileOffset - 512L).coerceAtLeast(0L)
                                    when (val r = hexReader.readChunk(workFile, prev, 512)) {
                                        is AppResult.Success -> {
                                            hexPage = r.data
                                            hexOffsetInput = prev.toString(16).uppercase()
                                        }
                                        is AppResult.Error -> hexStatusMessage = r.message
                                    }
                                }
                            ) { Text("◀ Prev") }
                            OutlinedButton(
                                enabled = page.fileOffset + 512L < page.totalFileSize,
                                onClick = {
                                    val next = page.fileOffset + 512L
                                    when (val r = hexReader.readChunk(workFile, next, 512)) {
                                        is AppResult.Success -> {
                                            hexPage = r.data
                                            hexOffsetInput = next.toString(16).uppercase()
                                        }
                                        is AppResult.Error -> hexStatusMessage = r.message
                                    }
                                }
                            ) { Text("Next ▶") }
                            OutlinedTextField(
                                value = hexOffsetInput,
                                onValueChange = { hexOffsetInput = it },
                                label = { Text("Hex Offset") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = {
                                val target = hexOffsetInput.removePrefix("0x").removePrefix("0X").toLongOrNull(16)
                                if (target == null) {
                                    hexStatusMessage = "Enter a valid hexadecimal offset (e.g. 100 or 0x2A0)."
                                } else {
                                    when (val r = hexReader.readChunk(workFile, target, 512)) {
                                        is AppResult.Success -> {
                                            hexPage = r.data
                                            hexStatusMessage = "Jumped to 0x${target.toString(16).uppercase()}"
                                        }
                                        is AppResult.Error -> hexStatusMessage = r.message
                                    }
                                }
                            }) { Text("Go") }
                        }

                        // Binary Search bar
                        Spacer(Modifier.height(6.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedTextField(
                                value = hexSearchInput,
                                onValueChange = { hexSearchInput = it },
                                label = { Text(if (hexSearchAsciiMode) "Search ASCII" else "Search Hex (e.g. 50 4B)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = hexSearchAsciiMode,
                                onClick = { hexSearchAsciiMode = !hexSearchAsciiMode },
                                label = { Text(if (hexSearchAsciiMode) "ASCII" else "HEX") }
                            )
                            TextButton(onClick = {
                                val patternResult = if (hexSearchAsciiMode) {
                                    if (hexSearchInput.isEmpty()) AppResult.Error("Enter ASCII text to search.")
                                    else AppResult.Success(hexSearchInput.toByteArray(Charsets.UTF_8))
                                } else {
                                    hexReader.parseHexString(hexSearchInput)
                                }
                                when (patternResult) {
                                    is AppResult.Error -> hexStatusMessage = patternResult.message
                                    is AppResult.Success -> {
                                        when (val sr = hexReader.searchBytes(workFile, patternResult.data)) {
                                            is AppResult.Success -> {
                                                hexSearchMatches = sr.data
                                                hexStatusMessage = "Found ${sr.data.size} match(es)"
                                                sr.data.firstOrNull()?.let { firstOff ->
                                                    (hexReader.readChunk(workFile, firstOff, 512) as? AppResult.Success)?.let {
                                                        hexPage = it.data
                                                        hexOffsetInput = firstOff.toString(16).uppercase()
                                                    }
                                                }
                                            }
                                            is AppResult.Error -> hexStatusMessage = sr.message
                                        }
                                    }
                                }
                            }) { Text("Find") }
                        }
                        if (hexSearchMatches.isNotEmpty()) {
                            Text(
                                "Matches: " + hexSearchMatches.take(10).joinToString(", ") { "0x${it.toString(16).uppercase()}" },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        // Byte Patching bar
                        Spacer(Modifier.height(6.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedTextField(
                                value = hexPatchOffsetInput,
                                onValueChange = { hexPatchOffsetInput = it },
                                label = { Text("Patch @ Hex") },
                                singleLine = true,
                                modifier = Modifier.width(110.dp)
                            )
                            OutlinedTextField(
                                value = hexPatchBytesInput,
                                onValueChange = { hexPatchBytesInput = it },
                                label = { Text("Hex Bytes (e.g. 90 90)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            Button(onClick = {
                                val off = hexPatchOffsetInput.removePrefix("0x").removePrefix("0X").toLongOrNull(16)
                                if (off == null) {
                                    hexStatusMessage = "Invalid patch hex offset."
                                } else {
                                    when (val parsed = hexReader.parseHexString(hexPatchBytesInput)) {
                                        is AppResult.Error -> hexStatusMessage = parsed.message
                                        is AppResult.Success -> {
                                            when (val wr = hexReader.writeBytesAtOffset(workFile, off, parsed.data)) {
                                                is AppResult.Error -> hexStatusMessage = wr.message
                                                is AppResult.Success -> {
                                                    val safUri = hexOriginSafUri
                                                    if (safUri != null) {
                                                        storageRepo.writeBytesToSafDocument(safUri, workFile.readBytes())
                                                    }
                                                    (hexReader.readChunk(workFile, page.fileOffset, 512) as? AppResult.Success)?.let {
                                                        hexPage = it.data
                                                    }
                                                    recordTask("Binary Patch", "Patched ${wr.data} byte(s) at 0x${off.toString(16).uppercase()} in $hexTitle")
                                                    hexStatusMessage = "Patched ${wr.data} byte(s) at 0x${off.toString(16).uppercase()}."
                                                    refreshDirectory()
                                                }
                                            }
                                        }
                                    }
                                }
                            }) { Text("Patch") }
                        }

                        hexStatusMessage?.let {
                            Spacer(Modifier.height(4.dp))
                            Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }

                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        // Hex grid output
                        Box(Modifier.horizontalScroll(rememberScrollState())) {
                            Text(
                                text = page.rows.joinToString("\n") { row ->
                                    "%08X  %-47s  %s".format(
                                        row.offset,
                                        row.hexColumns.joinToString(" "),
                                        row.asciiRepresentation
                                    )
                                },
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showHexDialog = false
                    if (hexOriginSafUri != null) workFile?.delete()
                }) { Text("Close") }
            }
        )
    }

    if (showOnboarding) {
        AlertDialog(
            onDismissRequest = { showOnboarding = false },
            title = { Text("Storage and privacy") },
            text = {
                Text(
                    "DroidForge uses Android's Storage Access Framework. Select a folder using the system picker to browse files shared by Android. " +
                        "Access remains limited to folders you grant. Multi-select copy/move, batch rename, ZIP extraction, text editing, and binary patching " +
                        "operate within your granted folders and app-private Workspace without bypassing Android's scoped-storage isolation."
                )
            },
            confirmButton = { TextButton(onClick = { showOnboarding = false }) { Text("Got it") } }
        )
    }
}

@Composable
private fun ToolRow(title: String, detail: String) {
    ListItem(
        headlineContent = { Text(title, fontWeight = FontWeight.SemiBold) },
        supportingContent = { Text(detail) },
        leadingContent = { Icon(Icons.Default.Build, null) }
    )
    HorizontalDivider()
}

@Composable
private fun ActionButton(label: String, enabled: Boolean = true, danger: Boolean = false, onClick: () -> Unit) {
    TextButton(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
        Text(label, color = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
    }
}
