# Dependency & Open-Source License Notice

All dependencies pinned in `gradle/libs.versions.toml` use permissive open-source licenses compatible with commercial and open-source distribution:

| Dependency | Version | License | Purpose |
| :--- | :--- | :--- | :--- |
| `androidx.core:core-ktx` | `1.15.0` | Apache License 2.0 | Core Android Kotlin extensions |
| `androidx.compose:compose-bom` | `2024.11.00` | Apache License 2.0 | Jetpack Compose UI & Material 3 |
| `androidx.lifecycle:*` | `2.8.7` | Apache License 2.0 | MVVM `ViewModel` & `StateFlow` lifecycle integration |
| `androidx.navigation:navigation-compose` | `2.8.4` | Apache License 2.0 | Compose screen navigation |
| `androidx.documentfile:documentfile` | `1.0.1` | Apache License 2.0 | Storage Access Framework (`DocumentFile`) wrapper |
| `androidx.room:*` | `2.6.1` | Apache License 2.0 | Local persistence for task history & bookmarks |
| `androidx.work:work-runtime-ktx` | `2.10.0` | Apache License 2.0 | Persistent background file & archive tasks |
| `org.jetbrains.kotlinx:kotlinx-coroutines-android` | `1.9.0` | Apache License 2.0 | Asynchronous I/O and structured concurrency |
| `org.apache.commons:commons-compress` | `1.27.1` | Apache License 2.0 | Archive format support |
| `junit:junit` | `4.13.2` | Eclipse Public License 1.0 | Unit testing framework |
