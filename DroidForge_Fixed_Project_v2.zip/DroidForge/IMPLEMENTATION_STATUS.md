# DroidForge implementation status (updated)

This file distinguishes usable UI features from engine-level code. It is not a claim that the Android project has been built with the Android SDK or tested on a physical device in this sandbox environment.

## Connected in the current source

- **Compose navigation**: Home, Files, Apps, Tools, Tasks, and Settings.
- **App-private Workspace & SAF browsing**:
  - Browse app-private `files/Workspace` or any shared storage / SD card folder selected via `ACTION_OPEN_DOCUMENT_TREE` (`OpenDocumentTree`) with persisted URI permissions.
  - Navigate directories, filter by name, toggle dotfiles, create folders, rename items, and delete items.
- **Multi-select, Cross-Storage Copy/Move & Batch Rename**:
  - Multi-select toolbar in Files with Select All, Clear, Copy, Cut (Move), Batch Rename, Create ZIP, and Batch Delete.
  - Persistent clipboard bar supporting copy/move across Workspace ↔ Workspace, Workspace ↔ SAF, and SAF ↔ SAF with configurable conflict resolution (`KEEP_BOTH`, `REPLACE`, `SKIP`).
  - Batch Rename dialog with prefix, suffix, find/replace, sequence numbering (`_01`, `_02`…), live collision preview, two-phase atomic rename for Workspace files, and SAF document rename support.
- **Interactive Hex Viewer & Byte Patcher**:
  - 512-byte chunked pagination (`Prev` / `Next` / hex offset jump) using `RandomAccessFile`.
  - Binary search by hexadecimal byte pattern or ASCII string.
  - In-place byte patching at arbitrary offsets, writing directly to Workspace files or saving back to SAF document URIs.
- **Text Editor with Undo/Redo & Safe Regex Find/Replace**:
  - Live document statistics (lines, words, characters, UTF-8 byte count, LF/CRLF indicator).
  - Bounded Undo/Redo history stack.
  - Find and Replace bar supporting case-sensitive and ReDoS-guarded regular expression replacements.
- **APK Inspector (Binary AXML, Signing Block & DEX Headers)**:
  - Binary `AndroidManifest.xml` (`0x00080003` AXML) and plain-XML decoder extracting package name, versionCode, versionName, minSdk, targetSdk, permissions, activities, services, receivers, providers, and a reconstructed XML preview.
  - APK Signing Block (`APK Sig Block 42`) detection for Signature Scheme v2 (`0x7109871a`) and v3 (`0xf05368c0` / `0x1b93ad61`), plus `META-INF` X.509 certificate extraction (Subject, Issuer, Serial, Algorithm, validity dates, and SHA-256 certificate fingerprint).
  - Multi-DEX (`classes*.dex`) header inspection and native `.so` library inventory.
- **Archive & App Management**:
  - Create `.zip` archives from multi-selected files/folders in Workspace or SAF folders.
  - Browse ZIP entries with Zip-Slip path traversal indicators and extract archives to either App Workspace or the currently open SAF/Workspace folder.
  - Installed Apps list with search, system-app filter, base APK backup to `Workspace/APKs`, direct APK manifest/certificate/DEX inspection, and system App Info shortcut.
- **Tasks & Tools**:
  - Session Task History screen tracking completed and failed file transfers, batch renames, ZIP operations, APK backups, duplicate scans, and binary patches.
  - Workspace Duplicate File Finder (grouped by file size + SHA-256).

## Remaining limitations

- APK Signing Block v2/v3 detection identifies block presence and extracts `META-INF` X.509 certificate metadata, but does not perform full cryptographic digest verification across every APK section.
- Binary AXML decoding reconstructs manifest structure and common Android resource attribute IDs (`name`, `versionCode`, `versionName`, `minSdkVersion`, `targetSdkVersion`, `label`, `icon`, `exported`), but does not decompile `resources.arsc` or Smali bytecode.
- Installed-app backup copies the base APK (`sourceDir`); split APKs and private app data directories remain protected by Android's sandbox.
- Google Play policy eligibility for `QUERY_ALL_PACKAGES` and `REQUEST_INSTALL_PACKAGES` must be reviewed before store publication.

## Build/test verification

- Static Kotlin source scan: verified zero embedded NUL bytes and verified all imports/types across all Kotlin source files.
- Pure-JVM smoke verification: executed automated tests covering binary AXML manifest decoding, APK Signing Block & DEX header parsing, SHA-256/MD5 checksums, hex chunk reading/searching/patching, text editor undo/redo and regex find/replace, two-phase batch rename, and ZIP creation/extraction/Zip-Slip blocking.
- Shell syntax check: `bash -n gradlew` passed.
- Not run in this sandbox: Gradle `assembleDebug`, Android Studio emulator/device tests (no Android SDK or outbound internet access in the sandbox VM).
