# DroidForge

DroidForge is an Android Kotlin + Jetpack Compose file manager, binary/text editor, and APK inspection toolkit. It uses Android's Storage Access Framework (SAF) for user-selected shared folders and app-private storage for its built-in Workspace.

## Open in Android Studio

1. Extract this project ZIP.
2. Open the `DroidForge` folder in Android Studio.
3. Use **Sync Project with Gradle Files** and allow Android Studio to download the pinned Gradle 8.9 distribution and Maven dependencies.
4. Select the `app` configuration and run on an Android device or emulator (API 26+).

The included `gradlew` and `gradlew.bat` are lightweight Gradle 8.9 bootstrap scripts. If Gradle is not already installed locally, they download Gradle 8.9 on first use and require network access.

## Connected Features

- **File Manager (Workspace & SAF)**:
  - Browse app-private `files/Workspace` or any shared folder / SD card granted through Android's system folder picker.
  - Multi-select mode with **Copy**, **Cut (Move)**, **Batch Rename**, **Create ZIP**, and **Batch Delete**.
  - Cross-storage clipboard supporting **Workspace ↔ SAF** and **SAF ↔ SAF** transfers with `KEEP_BOTH`, `REPLACE`, and `SKIP` conflict policies.
  - Batch Rename dialog with prefix, suffix, find/replace, sequence numbering, and collision detection.
- **Interactive Hex Viewer & Byte Patcher**:
  - Paginate 512-byte chunks (`Prev` / `Next` / hex offset jump), search by hex byte sequence or ASCII string, and patch bytes at any offset.
- **Text Editor**:
  - UTF-8 editor with live line/word/char/byte stats, **Undo / Redo** stack, and ReDoS-guarded literal/regex **Find & Replace**.
- **APK Inspector**:
  - Decodes binary `AndroidManifest.xml` (AXML `0x00080003`) and plain XML manifests, detects APK Signing Block v2/v3 schemes, extracts `META-INF` X.509 certificate details and SHA-256 fingerprints, and inspects `classes*.dex` headers and native `.so` libraries.
- **Archive & App Management**:
  - Create `.zip` archives from selected items and extract `.zip` archives to either App Workspace or the active SAF folder (with Zip-Slip traversal protection).
  - Browse installed apps, inspect their APKs in place, back up base APKs to `Workspace/APKs`, or open Android's system App Info page.
- **Tools & Session Tasks**:
  - Scan Workspace for duplicate files by SHA-256 and view a live log of session operations in the Tasks tab.

See `IMPLEMENTATION_STATUS.md` and `PERMISSIONS_AND_STORAGE.md` for storage boundaries and verification details.
