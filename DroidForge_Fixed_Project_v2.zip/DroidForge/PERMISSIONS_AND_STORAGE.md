# Permissions and Storage Behavior

1. **No broad storage permission is requested on launch.** The app starts in its app-private Workspace (`files/Workspace`).
2. **Storage Access Framework (SAF):** Select any shared folder or SD-card root using Android's system folder picker (`ACTION_OPEN_DOCUMENT_TREE`). DroidForge persists the URI permission where supported and restricts browsing and modifications to the selected folder tree.
3. **Cross-storage Copy, Move, and Batch Rename:** Multi-selected files and directories can be copied or moved across Workspace and granted SAF folders using `DocumentFile` streams and configurable conflict resolution (`KEEP_BOTH`, `REPLACE`, `SKIP`).
4. **Provider limitations:** Some third-party document providers do not support in-place rename, delete, or arbitrary subfolder creation. DroidForge surfaces clear error messages when a provider rejects an operation.
5. **Scoped storage isolation:** Android restricts direct access to `/Android/data`, `/Android/obb`, and private app sandboxes. DroidForge respects these OS boundaries.
6. **Installed package visibility & backup:** The app declares `QUERY_ALL_PACKAGES` for the Installed Apps browser and can copy an app's public base APK (`sourceDir`) into `Workspace/APKs`. Private app data cannot be accessed. Review Google Play policy requirements before publishing builds with `QUERY_ALL_PACKAGES` or `REQUEST_INSTALL_PACKAGES`.
7. **Temporary cache staging:** When inspecting or editing SAF documents (APK inspection, ZIP listing/extraction, hex viewing/patching, text editing), DroidForge stages a temporary working copy in app cache, writes changes back to the SAF URI when saved/patched, and deletes temporary cache files when closed.
