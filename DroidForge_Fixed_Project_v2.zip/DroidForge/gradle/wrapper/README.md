# Gradle bootstrap

This source bundle originally lacked the standard Gradle Wrapper JAR. `../gradlew` and `../gradlew.bat` are lightweight bootstrap scripts pinned to Gradle 8.9: they use an installed `gradle` executable when present, otherwise download and unpack the pinned Gradle distribution under the user's Gradle home.

The scripts do not include a binary wrapper JAR and require network access on the first run when Gradle is not already installed. In Android Studio, use **Sync Project with Gradle Files**; Android Studio can manage its own Gradle distribution as well.
