package com.intimedevs.droidforge

import com.intimedevs.droidforge.core.common.AppResult
import com.intimedevs.droidforge.core.fileops.ConflictPolicy
import com.intimedevs.droidforge.core.fileops.FileOperationsEngine
import com.intimedevs.droidforge.feature.apkinspector.ApkParserEngine
import com.intimedevs.droidforge.feature.archive.ZipArchiveEngine
import com.intimedevs.droidforge.feature.hexviewer.ChunkedHexReader
import com.intimedevs.droidforge.feature.texteditor.TextEditorEngine
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class DroidForgeCoreUnitTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private val fileOps = FileOperationsEngine()
    private val zipEngine = ZipArchiveEngine()
    private val hexReader = ChunkedHexReader()
    private val textEngine = TextEditorEngine()
    private val apkEngine = ApkParserEngine(fileOps)

    @Test
    fun copyWithKeepBothResolvesConflictSafely() {
        val srcDir = tempFolder.newFolder("src")
        val dstDir = tempFolder.newFolder("dst")
        val f1 = File(srcDir, "report.txt").apply { writeText("version 2") }
        File(dstDir, "report.txt").apply { writeText("version 1") }

        val res = fileOps.copyOrMoveFiles(listOf(f1), dstDir, move = false, conflictPolicy = ConflictPolicy.KEEP_BOTH)
        assertTrue(res is AppResult.Success)
        assertTrue(File(dstDir, "report.txt").exists())
        assertTrue(File(dstDir, "report_(1).txt").exists())
        assertEquals("version 1", File(dstDir, "report.txt").readText())
        assertEquals("version 2", File(dstDir, "report_(1).txt").readText())
    }

    @Test
    fun zipSlipTraversalEntryIsRejectedDuringExtraction() {
        val evilZip = tempFolder.newFile("evil.zip")
        ZipOutputStream(FileOutputStream(evilZip)).use { zos ->
            zos.putNextEntry(ZipEntry("../../escaped.txt"))
            zos.write("malicious payload".toByteArray())
            zos.closeEntry()
        }
        val extractTarget = tempFolder.newFolder("safe_extract")
        val result = zipEngine.extractArchive(evilZip, extractTarget)
        assertTrue("Expected Zip-Slip security error", result is AppResult.Error)
        val errMsg = (result as AppResult.Error).message
        assertTrue(errMsg.contains("Zip-Slip blocked"))
    }

    @Test
    fun batchRenameDetectsDuplicateTargetCollisionsAndAppliesCleanRenames() {
        val dir = tempFolder.newFolder("batch")
        val a = File(dir, "item_a.txt").apply { writeText("1") }
        val b = File(dir, "item_b.txt").apply { writeText("2") }

        val collisionPreview = fileOps.previewBatchRename(
            files = listOf(a, b),
            findText = "_b",
            replaceText = "_a"
        )
        assertEquals(2, collisionPreview.size)
        assertFalse(collisionPreview[0].hasCollision)
        assertTrue("Second item should report collision with first item", collisionPreview[1].hasCollision)

        val validPreview = fileOps.previewBatchRename(
            files = listOf(a, b),
            prefix = "renamed_",
            startNumber = 1
        )
        assertTrue(validPreview.none { it.hasCollision })
        val applied = fileOps.applyBatchRename(validPreview)
        assertTrue(applied is AppResult.Success)
        assertEquals(2, (applied as AppResult.Success).data)
        assertTrue(File(dir, "renamed_item_a_01.txt").exists())
        assertTrue(File(dir, "renamed_item_b_02.txt").exists())
    }

    @Test
    fun chunkedHexReaderReadsSearchesAndPatchesBytesWithoutFullFileLoad() {
        val bin = tempFolder.newFile("sample.bin")
        bin.writeBytes(ByteArray(1024) { (it % 256).toByte() })

        val pageResult = hexReader.readChunk(bin, offset = 256L, byteCount = 64)
        assertTrue(pageResult is AppResult.Success)
        val page = (pageResult as AppResult.Success).data
        assertEquals(4, page.rows.size)
        assertEquals(256L, page.rows.first().offset)
        assertEquals("00", page.rows.first().hexColumns.first())

        val parsed = hexReader.parseHexString("DE AD BE EF")
        assertTrue(parsed is AppResult.Success)
        val patchBytes = (parsed as AppResult.Success).data
        val patchRes = hexReader.writeBytesAtOffset(bin, 128L, patchBytes)
        assertTrue(patchRes is AppResult.Success)

        val searchRes = hexReader.searchBytes(bin, patchBytes)
        assertTrue(searchRes is AppResult.Success)
        assertEquals(listOf(128L), (searchRes as AppResult.Success).data)
    }

    @Test
    fun textEditorSupportsUndoRedoAndSafeRegexReplace() {
        val txt = tempFolder.newFile("notes.txt").apply { writeText("alpha beta alpha") }
        val opened = (textEngine.openDocument(txt) as AppResult.Success).data

        val edited1 = textEngine.applyEdit(opened, "alpha gamma alpha")
        assertTrue(edited1.canUndo)
        val undone = textEngine.undo(edited1)
        assertEquals("alpha beta alpha", undone.content)
        assertTrue(undone.canRedo)
        val redone = textEngine.redo(undone)
        assertEquals("alpha gamma alpha", redone.content)

        val replaced = textEngine.replaceAllMatches(
            state = redone,
            query = "alpha",
            replacement = "delta",
            useRegex = false,
            caseSensitive = true
        )
        assertTrue(replaced is AppResult.Success)
        val (afterReplace, count) = (replaced as AppResult.Success).data
        assertEquals(2, count)
        assertEquals("delta gamma delta", afterReplace.content)
    }

    @Test
    fun catastrophicRegexIsRejectedBySafeRegexFinder() {
        val result = textEngine.safeFindMatches(
            text = "aaaaaaaaaaaaaaaaaaaaaaaaaaaa!",
            query = "(a+)+$",
            useRegex = true,
            caseSensitive = true
        )
        assertTrue(result is AppResult.Error)
    }

    @Test
    fun binaryAxmlManifestParserExtractsPackageAndSdkMetadata() {
        // Construct a minimal valid binary AXML with UTF-16LE string pool and <manifest package="com.intimedevs.droidforge">
        val strings = listOf("manifest", "package", "com.intimedevs.droidforge")
        val poolBytes = buildUtf16StringPoolChunk(strings)
        val startElemBytes = buildStartElementChunk(nameIdx = 0, attrNameIdx = 1, attrValIdx = 2)
        val endElemBytes = buildEndElementChunk(nameIdx = 0)
        val totalSize = 8 + poolBytes.size + startElemBytes.size + endElemBytes.size
        val axml = ByteBuffer.allocate(totalSize).order(ByteOrder.LITTLE_ENDIAN).apply {
            putShort(0x0003)
            putShort(8)
            putInt(totalSize)
            put(poolBytes)
            put(startElemBytes)
            put(endElemBytes)
        }.array()

        val summary = apkEngine.parseAndroidManifestBytes(axml)
        assertNotNull(summary)
        assertTrue(summary!!.isBinaryAxml)
        assertEquals("com.intimedevs.droidforge", summary.packageName)
        assertTrue(summary.decodedXmlPreview.contains("<manifest package=\"com.intimedevs.droidforge\">"))
    }

    private fun buildUtf16StringPoolChunk(strings: List<String>): ByteArray {
        val encoded = strings.map { s ->
            val chars = s.toByteArray(Charsets.UTF_16LE)
            ByteBuffer.allocate(2 + chars.size + 2).order(ByteOrder.LITTLE_ENDIAN).apply {
                putShort(s.length.toShort())
                put(chars)
                putShort(0)
            }.array()
        }
        val offsets = IntArray(strings.size)
        var running = 0
        for (i in encoded.indices) {
            offsets[i] = running
            running += encoded[i].size
        }
        val pad = (4 - (running % 4)) % 4
        val stringsStart = 28 + strings.size * 4
        val chunkSize = stringsStart + running + pad
        return ByteBuffer.allocate(chunkSize).order(ByteOrder.LITTLE_ENDIAN).apply {
            putShort(0x0001)
            putShort(28)
            putInt(chunkSize)
            putInt(strings.size)
            putInt(0)
            putInt(0) // UTF-16LE flags
            putInt(stringsStart)
            putInt(0)
            offsets.forEach { putInt(it) }
            encoded.forEach { put(it) }
            repeat(pad) { put(0) }
        }.array()
    }

    private fun buildStartElementChunk(nameIdx: Int, attrNameIdx: Int, attrValIdx: Int): ByteArray {
        val chunkSize = 36 + 20
        return ByteBuffer.allocate(chunkSize).order(ByteOrder.LITTLE_ENDIAN).apply {
            putShort(0x0102)
            putShort(16)
            putInt(chunkSize)
            putInt(1) // line
            putInt(-1) // comment
            putInt(-1) // ns
            putInt(nameIdx)
            putShort(20) // attrStart
            putShort(20) // attrSize
            putShort(1)  // attrCount
            putShort(0)
            putShort(0)
            putShort(0)
            // 1 attribute (20 bytes)
            putInt(-1) // ns
            putInt(attrNameIdx)
            putInt(attrValIdx)
            putShort(8)
            put(0)
            put(0x03) // TYPE_STRING
            putInt(attrValIdx)
        }.array()
    }

    private fun buildEndElementChunk(nameIdx: Int): ByteArray {
        return ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN).apply {
            putShort(0x0103)
            putShort(16)
            putInt(24)
            putInt(2)
            putInt(-1)
            putInt(-1)
            putInt(nameIdx)
        }.array()
    }
}
