package com.intimedevs.droidforge.core.common

sealed interface AppResult<out T> {
    data class Success<T>(val data: T) : AppResult<T>
    data class Error(
        val message: String,
        val cause: Throwable? = null,
        val recoverable: Boolean = true
    ) : AppResult<Nothing>
}

object FileSizeFormatter {
    fun formatBytes(bytes: Long): String {
        if (bytes < 0) return "0 B"
        if (bytes < 1024) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var value = bytes.toDouble()
        var unitIndex = -1
        while (value >= 1024 && unitIndex < units.lastIndex) {
            value /= 1024.0
            unitIndex++
        }
        return String.format("%.2f %s", value, units[unitIndex])
    }
}

/**
 * Redacts user-specific storage paths and never logs file contents, tokens, or keys.
 */
object RedactingLogger {
    private val sensitivePathRegex = Regex("(/storage/emulated/\\d+/|/data/user/\\d+/[^/]+/)")

    fun redact(rawMessage: String): String {
        return sensitivePathRegex.replace(rawMessage, "<REDACTED_STORAGE_ROOT>/")
    }
}
