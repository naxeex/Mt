package com.intimedevs.droidforge.feature.apkinspector

import com.intimedevs.droidforge.core.common.AppResult
import com.intimedevs.droidforge.core.fileops.FileOperationsEngine
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.util.zip.ZipFile

data class DexHeaderSummary(
    val entryName: String,
    val dexVersion: String,
    val fileSize: Int,
    val stringIdsSize: Int,
    val typeIdsSize: Int,
    val protoIdsSize: Int,
    val fieldIdsSize: Int,
    val methodIdsSize: Int,
    val classDefsSize: Int
)

data class ManifestSummary(
    val isBinaryAxml: Boolean,
    val packageName: String,
    val versionCode: String,
    val versionName: String,
    val minSdk: String,
    val targetSdk: String,
    val permissions: List<String>,
    val activities: List<String>,
    val services: List<String>,
    val receivers: List<String>,
    val providers: List<String>,
    val decodedXmlPreview: String
)

data class CertificateSummary(
    val entryName: String,
    val subjectDn: String,
    val issuerDn: String,
    val serialNumberHex: String,
    val sigAlgName: String,
    val validFrom: String,
    val validUntil: String,
    val sha256Fingerprint: String
)

data class ApkSignatureSummary(
    val v1SignatureEntries: List<String>,
    val hasApkSigBlock: Boolean,
    val hasV2SchemeBlock: Boolean,
    val hasV3SchemeBlock: Boolean,
    val certificates: List<CertificateSummary>
)

data class ApkInspectionReport(
    val fileName: String,
    val fileSizeBytes: Long,
    val sha256: String,
    val hasAndroidManifest: Boolean,
    val hasResourcesArsc: Boolean,
    val manifestSummary: ManifestSummary?,
    val signatureSummary: ApkSignatureSummary,
    val dexFiles: List<DexHeaderSummary>,
    val nativeLibraries: List<String>,
    val signatureFiles: List<String>,
    val totalArchiveEntries: Int
)

data class ApkComparisonReport(
    val leftApkName: String,
    val rightApkName: String,
    val sizeDeltaBytes: Long,
    val addedEntries: List<String>,
    val removedEntries: List<String>,
    val modifiedEntries: List<String>
)

class ApkParserEngine(
    private val fileOps: FileOperationsEngine = FileOperationsEngine()
) {

    fun inspectApkArchive(apkFile: File): AppResult<ApkInspectionReport> {
        if (!apkFile.exists() || !apkFile.canRead()) {
            return AppResult.Error("APK file is not readable: ${apkFile.name}")
        }
        val checksumResult = fileOps.computeChecksums(apkFile)
        val sha256 = (checksumResult as? AppResult.Success)?.data?.sha256 ?: "unavailable"

        return try {
            ZipFile(apkFile).use { zf ->
                var hasManifest = false
                var hasArsc = false
                var manifestSummary: ManifestSummary? = null
                val dexSummaries = mutableListOf<DexHeaderSummary>()
                val nativeLibs = mutableListOf<String>()
                val signatures = mutableListOf<String>()
                val certSummaries = mutableListOf<CertificateSummary>()
                var totalEntries = 0

                val entries = zf.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    totalEntries++
                    when {
                        entry.name == "AndroidManifest.xml" -> {
                            hasManifest = true
                            val bytes = zf.getInputStream(entry).use { it.readBytes() }
                            manifestSummary = parseAndroidManifestBytes(bytes)
                        }
                        entry.name == "resources.arsc" -> hasArsc = true
                        entry.name.matches(Regex("classes\\d*\\.dex")) -> {
                            parseDexHeader(zf, entry.name)?.let { dexSummaries += it }
                        }
                        entry.name.startsWith("lib/") && entry.name.endsWith(".so") -> {
                            nativeLibs += entry.name
                        }
                        entry.name.startsWith("META-INF/") &&
                            (entry.name.endsWith(".RSA") || entry.name.endsWith(".DSA") || entry.name.endsWith(".EC") || entry.name.endsWith(".SF")) -> {
                            signatures += entry.name
                            if (!entry.name.endsWith(".SF")) {
                                certSummaries += parseCertificatesFromEntry(zf, entry.name)
                            }
                        }
                    }
                }

                if (!hasManifest && dexSummaries.isEmpty()) {
                    return AppResult.Error("File does not appear to be a valid Android APK (missing AndroidManifest.xml and classes.dex).")
                }

                val sigBlockInfo = detectApkSigningBlock(apkFile)
                val sigSummary = ApkSignatureSummary(
                    v1SignatureEntries = signatures.sorted(),
                    hasApkSigBlock = sigBlockInfo.first,
                    hasV2SchemeBlock = sigBlockInfo.second,
                    hasV3SchemeBlock = sigBlockInfo.third,
                    certificates = certSummaries
                )

                AppResult.Success(
                    ApkInspectionReport(
                        fileName = apkFile.name,
                        fileSizeBytes = apkFile.length(),
                        sha256 = sha256,
                        hasAndroidManifest = hasManifest,
                        hasResourcesArsc = hasArsc,
                        manifestSummary = manifestSummary,
                        signatureSummary = sigSummary,
                        dexFiles = dexSummaries.sortedBy { it.entryName },
                        nativeLibraries = nativeLibs.sorted(),
                        signatureFiles = signatures.sorted(),
                        totalArchiveEntries = totalEntries
                    )
                )
            }
        } catch (e: Exception) {
            AppResult.Error("APK parse failure: ${e.message}", e)
        }
    }

    /**
     * Parses either binary Android AXML (0x00080003) or plain-text XML AndroidManifest.xml.
     */
    fun parseAndroidManifestBytes(bytes: ByteArray): ManifestSummary? {
        if (bytes.size < 4) return null
        val magic = ByteBuffer.wrap(bytes, 0, 4).order(ByteOrder.LITTLE_ENDIAN).int
        return if (magic == 0x00080003) {
            decodeBinaryAxml(bytes)
        } else {
            val text = bytes.toString(Charsets.UTF_8).trim()
            if (text.startsWith("<")) parsePlainTextManifest(text) else null
        }
    }

    private fun parsePlainTextManifest(xmlText: String): ManifestSummary {
        fun attr(tagRegex: String, attrName: String): String {
            val tagMatch = Regex(tagRegex, setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)).find(xmlText)?.value ?: return ""
            val m = Regex("""(?:android:)?$attrName\s*=\s*["']([^"']+)["']""").find(tagMatch)
            return m?.groupValues?.getOrNull(1).orEmpty()
        }

        fun collectComponentNames(tagName: String): List<String> {
            return Regex("""<$tagName\b[^>]*>""", RegexOption.DOT_MATCHES_ALL)
                .findAll(xmlText)
                .mapNotNull { m ->
                    Regex("""(?:android:)?name\s*=\s*["']([^"']+)["']""").find(m.value)?.groupValues?.getOrNull(1)
                }
                .toList()
        }

        val pkg = attr("""<manifest\b[^>]*>""", "package").ifBlank { "unknown" }
        val vCode = attr("""<manifest\b[^>]*>""", "versionCode").ifBlank { "N/A" }
        val vName = attr("""<manifest\b[^>]*>""", "versionName").ifBlank { "N/A" }
        val minSdk = attr("""<uses-sdk\b[^>]*>""", "minSdkVersion").ifBlank { "N/A" }
        val targetSdk = attr("""<uses-sdk\b[^>]*>""", "targetSdkVersion").ifBlank { "N/A" }
        val perms = collectComponentNames("uses-permission")
        return ManifestSummary(
            isBinaryAxml = false,
            packageName = pkg,
            versionCode = vCode,
            versionName = vName,
            minSdk = minSdk,
            targetSdk = targetSdk,
            permissions = perms,
            activities = collectComponentNames("activity"),
            services = collectComponentNames("service"),
            receivers = collectComponentNames("receiver"),
            providers = collectComponentNames("provider"),
            decodedXmlPreview = xmlText.take(4000)
        )
    }

    private fun decodeBinaryAxml(bytes: ByteArray): ManifestSummary? {
        return try {
            val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            if (bytes.size < 8) return null
            val fileHeaderSize = buf.getShort(2).toInt() and 0xFFFF
            var pos = fileHeaderSize

            var strings: List<String> = emptyList()
            var resourceIds: IntArray = IntArray(0)

            var packageName = "unknown"
            var versionCode = "N/A"
            var versionName = "N/A"
            var minSdk = "N/A"
            var targetSdk = "N/A"
            val permissions = mutableListOf<String>()
            val activities = mutableListOf<String>()
            val services = mutableListOf<String>()
            val receivers = mutableListOf<String>()
            val providers = mutableListOf<String>()

            val xmlBuilder = StringBuilder()
            var indent = 0

            while (pos + 8 <= bytes.size) {
                val chunkType = buf.getShort(pos).toInt() and 0xFFFF
                val headerSize = buf.getShort(pos + 2).toInt() and 0xFFFF
                val chunkSize = buf.getInt(pos + 4)
                if (chunkSize <= 0 || pos + chunkSize > bytes.size) break

                when (chunkType) {
                    0x0001 -> { // RES_STRING_POOL_TYPE
                        strings = parseAxmlStringPool(buf, pos, headerSize, chunkSize)
                    }
                    0x0180 -> { // RES_XML_RESOURCE_MAP_TYPE
                        val count = (chunkSize - headerSize) / 4
                        resourceIds = IntArray(count.coerceAtLeast(0)) { i ->
                            buf.getInt(pos + headerSize + i * 4)
                        }
                    }
                    0x0102 -> { // RES_XML_START_ELEMENT_TYPE
                        if (pos + 36 <= bytes.size) {
                            val nameIdx = buf.getInt(pos + 20)
                            val attrStart = buf.getShort(pos + 24).toInt() and 0xFFFF
                            val attrSize = (buf.getShort(pos + 26).toInt() and 0xFFFF).coerceAtLeast(20)
                            val attrCount = buf.getShort(pos + 28).toInt() and 0xFFFF
                            val elemName = strings.getOrNull(nameIdx) ?: "tag_$nameIdx"

                            val attrs = mutableMapOf<String, String>()
                            var attrPos = pos + 16 + attrStart
                            for (i in 0 until attrCount) {
                                if (attrPos + 20 > pos + chunkSize) break
                                val attrNameIdx = buf.getInt(attrPos + 4)
                                val rawValIdx = buf.getInt(attrPos + 8)
                                val dataType = buf.get(attrPos + 15).toInt() and 0xFF
                                val data = buf.getInt(attrPos + 16)

                                val attrName = resolveAttributeName(attrNameIdx, strings, resourceIds)
                                val attrVal = resolveAttributeValue(rawValIdx, dataType, data, strings)
                                attrs[attrName] = attrVal
                                attrPos += attrSize
                            }

                            when (elemName) {
                                "manifest" -> {
                                    attrs["package"]?.let { packageName = it }
                                    attrs["versionCode"]?.let { versionCode = it }
                                    attrs["versionName"]?.let { versionName = it }
                                }
                                "uses-sdk" -> {
                                    attrs["minSdkVersion"]?.let { minSdk = it }
                                    attrs["targetSdkVersion"]?.let { targetSdk = it }
                                }
                                "uses-permission", "uses-permission-sdk-23" -> {
                                    attrs["name"]?.let { permissions += it }
                                }
                                "activity", "activity-alias" -> attrs["name"]?.let { activities += it }
                                "service" -> attrs["name"]?.let { services += it }
                                "receiver" -> attrs["name"]?.let { receivers += it }
                                "provider" -> attrs["name"]?.let { providers += it }
                            }

                            if (xmlBuilder.length < 4000) {
                                val pad = "  ".repeat(indent.coerceIn(0, 12))
                                val attrStr = if (attrs.isEmpty()) "" else " " + attrs.entries.joinToString(" ") { "${it.key}=\"${it.value}\"" }
                                xmlBuilder.append(pad).append("<").append(elemName).append(attrStr).append(">\n")
                            }
                            indent++
                        }
                    }
                    0x0103 -> { // RES_XML_END_ELEMENT_TYPE
                        indent = (indent - 1).coerceAtLeast(0)
                        if (pos + 24 <= bytes.size && xmlBuilder.length < 4000) {
                            val nameIdx = buf.getInt(pos + 20)
                            val elemName = strings.getOrNull(nameIdx) ?: "tag_$nameIdx"
                            val pad = "  ".repeat(indent.coerceIn(0, 12))
                            xmlBuilder.append(pad).append("</").append(elemName).append(">\n")
                        }
                    }
                }
                pos += chunkSize
            }

            ManifestSummary(
                isBinaryAxml = true,
                packageName = packageName,
                versionCode = versionCode,
                versionName = versionName,
                minSdk = minSdk,
                targetSdk = targetSdk,
                permissions = permissions.distinct(),
                activities = activities.distinct(),
                services = services.distinct(),
                receivers = receivers.distinct(),
                providers = providers.distinct(),
                decodedXmlPreview = xmlBuilder.toString().trim()
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun parseAxmlStringPool(buf: ByteBuffer, chunkPos: Int, headerSize: Int, chunkSize: Int): List<String> {
        if (chunkPos + 28 > buf.limit()) return emptyList()
        val stringCount = buf.getInt(chunkPos + 8)
        val flags = buf.getInt(chunkPos + 16)
        val stringsStart = buf.getInt(chunkPos + 20)
        val isUtf8 = (flags and 0x100) != 0
        val offsetsBase = chunkPos + headerSize
        val poolBase = chunkPos + stringsStart
        val chunkEnd = chunkPos + chunkSize
        val result = ArrayList<String>(stringCount.coerceIn(0, 50_000))

        for (i in 0 until stringCount.coerceIn(0, 50_000)) {
            val offsetPos = offsetsBase + i * 4
            if (offsetPos + 4 > chunkEnd) break
            val strOffset = buf.getInt(offsetPos)
            var p = poolBase + strOffset
            if (p < poolBase || p >= chunkEnd) {
                result += ""
                continue
            }
            if (isUtf8) {
                // Skip UTF-16 length (1 or 2 bytes)
                val b0 = buf.get(p).toInt() and 0xFF
                p += if ((b0 and 0x80) != 0) 2 else 1
                if (p >= chunkEnd) {
                    result += ""
                    continue
                }
                val b1 = buf.get(p).toInt() and 0xFF
                val byteLen = if ((b1 and 0x80) != 0) {
                    p += 1
                    if (p >= chunkEnd) 0 else ((b1 and 0x7F) shl 8) or (buf.get(p).toInt() and 0xFF)
                } else {
                    b1
                }
                p += 1
                val safeLen = byteLen.coerceIn(0, (chunkEnd - p).coerceAtLeast(0))
                val strBytes = ByteArray(safeLen) { k -> buf.get(p + k) }
                result += String(strBytes, Charsets.UTF_8)
            } else {
                if (p + 2 > chunkEnd) {
                    result += ""
                    continue
                }
                val u0 = buf.getShort(p).toInt() and 0xFFFF
                val charLen = if ((u0 and 0x8000) != 0) {
                    p += 2
                    if (p + 2 > chunkEnd) 0 else ((u0 and 0x7FFF) shl 16) or (buf.getShort(p).toInt() and 0xFFFF)
                } else {
                    u0
                }
                p += 2
                val byteLen = (charLen * 2).coerceIn(0, (chunkEnd - p).coerceAtLeast(0))
                val strBytes = ByteArray(byteLen) { k -> buf.get(p + k) }
                result += String(strBytes, Charsets.UTF_16LE)
            }
        }
        return result
    }

    private fun resolveAttributeName(attrNameIdx: Int, strings: List<String>, resourceIds: IntArray): String {
        val raw = strings.getOrNull(attrNameIdx).orEmpty()
        if (raw.isNotBlank()) return raw
        val resId = resourceIds.getOrNull(attrNameIdx) ?: return "attr_$attrNameIdx"
        return when (resId) {
            0x01010003 -> "name"
            0x0101021b -> "versionCode"
            0x0101021c -> "versionName"
            0x0101020c -> "minSdkVersion"
            0x01010270 -> "targetSdkVersion"
            0x01010001 -> "label"
            0x01010002 -> "icon"
            0x0101001e -> "exported"
            else -> "attr_0x${resId.toUInt().toString(16)}"
        }
    }

    private fun resolveAttributeValue(rawValIdx: Int, dataType: Int, data: Int, strings: List<String>): String {
        if (rawValIdx >= 0 && rawValIdx < strings.size) {
            return strings[rawValIdx]
        }
        return when (dataType) {
            0x03 -> strings.getOrNull(data).orEmpty()
            0x10 -> data.toString()
            0x11 -> "0x${data.toUInt().toString(16)}"
            0x12 -> (data != 0).toString()
            0x01 -> "@0x${data.toUInt().toString(16)}"
            else -> data.toString()
        }
    }

    private fun parseCertificatesFromEntry(zf: ZipFile, entryName: String): List<CertificateSummary> {
        val entry = zf.getEntry(entryName) ?: return emptyList()
        return try {
            zf.getInputStream(entry).use { input ->
                val cf = CertificateFactory.getInstance("X.509")
                val certs = cf.generateCertificates(input)
                certs.filterIsInstance<X509Certificate>().map { cert ->
                    val sha256 = MessageDigest.getInstance("SHA-256")
                        .digest(cert.encoded)
                        .joinToString(":") { "%02X".format(it) }
                    CertificateSummary(
                        entryName = entryName,
                        subjectDn = cert.subjectX500Principal.name,
                        issuerDn = cert.issuerX500Principal.name,
                        serialNumberHex = cert.serialNumber.toString(16).uppercase(),
                        sigAlgName = cert.sigAlgName,
                        validFrom = cert.notBefore.toString(),
                        validUntil = cert.notAfter.toString(),
                        sha256Fingerprint = sha256
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * Checks the APK file for an APK Signing Block ("APK Sig Block 42") immediately preceding
     * the ZIP Central Directory, and inspects ID-value pairs for v2 (0x7109871a) and v3 (0xf05368c0 / 0x1b93ad61).
     */
    private fun detectApkSigningBlock(apkFile: File): Triple<Boolean, Boolean, Boolean> {
        return try {
            RandomAccessFile(apkFile, "r").use { raf ->
                val fileLen = raf.length()
                if (fileLen < 54) return Triple(false, false, false)
                val searchLen = minOf(fileLen, 65557L).toInt()
                val tail = ByteArray(searchLen)
                raf.seek(fileLen - searchLen)
                raf.readFully(tail)
                val tailBuf = ByteBuffer.wrap(tail).order(ByteOrder.LITTLE_ENDIAN)
                var eocdOffsetInTail = -1
                for (i in searchLen - 22 downTo 0) {
                    if (tailBuf.getInt(i) == 0x06054b50) {
                        eocdOffsetInTail = i
                        break
                    }
                }
                if (eocdOffsetInTail < 0) return Triple(false, false, false)
                val cdOffset = tailBuf.getInt(eocdOffsetInTail + 16).toLong() and 0xFFFFFFFFL
                if (cdOffset < 32L || cdOffset > fileLen) return Triple(false, false, false)

                val footer = ByteArray(24)
                raf.seek(cdOffset - 24L)
                raf.readFully(footer)
                val footerBuf = ByteBuffer.wrap(footer).order(ByteOrder.LITTLE_ENDIAN)
                val sizeInFooter = footerBuf.getLong(0)
                val magicLo = footerBuf.getLong(8)
                val magicHi = footerBuf.getLong(16)
                // "APK Sig Block 42" in little-endian 64-bit halves
                if (magicLo != 0x20676953204b5041L || magicHi != 0x3234206b636f6c42L) {
                    return Triple(false, false, false)
                }
                val blockStart = cdOffset - sizeInFooter - 8L
                if (blockStart < 0L || sizeInFooter < 24L || sizeInFooter > 32 * 1024 * 1024L) {
                    return Triple(true, false, false)
                }
                var hasV2 = false
                var hasV3 = false
                var pos = blockStart + 8L
                val pairsEnd = cdOffset - 24L
                val pairHeader = ByteArray(12)
                while (pos + 12L <= pairsEnd) {
                    raf.seek(pos)
                    raf.readFully(pairHeader)
                    val pairBuf = ByteBuffer.wrap(pairHeader).order(ByteOrder.LITTLE_ENDIAN)
                    val pairLen = pairBuf.getLong(0)
                    val pairId = pairBuf.getInt(8)
                    if (pairLen < 4L || pos + 8L + pairLen > pairsEnd) break
                    if (pairId == 0x7109871a) hasV2 = true
                    if (pairId == -0xfac9740 || pairId == 0x1b93ad61) hasV3 = true // 0xf05368c0 signed int = -0xfac9740
                    pos += 8L + pairLen
                }
                Triple(true, hasV2, hasV3)
            }
        } catch (_: Exception) {
            Triple(false, false, false)
        }
    }

    private fun parseDexHeader(zf: ZipFile, entryName: String): DexHeaderSummary? {
        val entry = zf.getEntry(entryName) ?: return null
        zf.getInputStream(entry).use { input ->
            val headerBytes = ByteArray(112)
            var offset = 0
            while (offset < headerBytes.size) {
                val read = input.read(headerBytes, offset, headerBytes.size - offset)
                if (read <= 0) break
                offset += read
            }
            if (offset < 112) return null
            val magicPrefix = String(headerBytes, 0, 4, Charsets.US_ASCII)
            if (magicPrefix != "dex\n") return null
            val version = String(headerBytes, 4, 3, Charsets.US_ASCII)
            val buf = ByteBuffer.wrap(headerBytes).order(ByteOrder.LITTLE_ENDIAN)
            val fileSize = buf.getInt(32)
            val stringIdsSize = buf.getInt(56)
            val typeIdsSize = buf.getInt(64)
            val protoIdsSize = buf.getInt(72)
            val fieldIdsSize = buf.getInt(80)
            val methodIdsSize = buf.getInt(88)
            val classDefsSize = buf.getInt(96)
            return DexHeaderSummary(
                entryName = entryName,
                dexVersion = version,
                fileSize = fileSize,
                stringIdsSize = stringIdsSize,
                typeIdsSize = typeIdsSize,
                protoIdsSize = protoIdsSize,
                fieldIdsSize = fieldIdsSize,
                methodIdsSize = methodIdsSize,
                classDefsSize = classDefsSize
            )
        }
    }

    fun compareApks(leftApk: File, rightApk: File): AppResult<ApkComparisonReport> {
        return try {
            ZipFile(leftApk).use { leftZf ->
                ZipFile(rightApk).use { rightZf ->
                    val leftMap = leftZf.entries().asSequence()
                        .filter { !it.isDirectory }
                        .associate { it.name to Pair(it.crc, it.size) }
                    val rightMap = rightZf.entries().asSequence()
                        .filter { !it.isDirectory }
                        .associate { it.name to Pair(it.crc, it.size) }

                    val added = (rightMap.keys - leftMap.keys).sorted()
                    val removed = (leftMap.keys - rightMap.keys).sorted()
                    val modified = leftMap.keys.intersect(rightMap.keys)
                        .filter { leftMap[it] != rightMap[it] }
                        .sorted()

                    AppResult.Success(
                        ApkComparisonReport(
                            leftApkName = leftApk.name,
                            rightApkName = rightApk.name,
                            sizeDeltaBytes = rightApk.length() - leftApk.length(),
                            addedEntries = added,
                            removedEntries = removed,
                            modifiedEntries = modified
                        )
                    )
                }
            }
        } catch (e: Exception) {
            AppResult.Error("APK comparison failed: ${e.message}", e)
        }
    }
}
