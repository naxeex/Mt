package com.intimedevs.droidforge.feature.texteditor

import com.intimedevs.droidforge.core.common.AppResult
import java.io.File
import java.nio.charset.Charset

data class TextDocumentStats(
    val charCount: Int,
    val lineCount: Int,
    val wordCount: Int,
    val byteCountUtf8: Int
)

data class EditorDocumentState(
    val filePath: String,
    val fileName: String,
    val content: String,
    val savedDiskModifiedTime: Long,
    val isDirty: Boolean = false,
    val isReadOnly: Boolean = false,
    val encodingName: String = "UTF-8",
    val lineEndingStyle: String = "LF",
    val undoStack: List<String> = emptyList(),
    val redoStack: List<String> = emptyList()
) {
    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()
}

class TextEditorEngine {

    companion object {
        const val LARGE_FILE_THRESHOLD_BYTES = 1024L * 1024L // 1 MB threshold for large-file windowed mode
        const val MAX_REGEX_PATTERN_LENGTH = 256
        const val MAX_UNDO_HISTORY = 40
    }

    fun openDocument(file: File, charset: Charset = Charsets.UTF_8): AppResult<EditorDocumentState> {
        if (!file.exists() || !file.canRead()) {
            return AppResult.Error("Cannot read file: ${file.name}")
        }
        return try {
            val isLarge = file.length() > LARGE_FILE_THRESHOLD_BYTES
            val rawText = if (isLarge) {
                file.inputStream().bufferedReader(charset).use { reader ->
                    val buffer = CharArray(128 * 1024)
                    val read = reader.read(buffer)
                    if (read > 0) String(buffer, 0, read) else ""
                }
            } else {
                file.readText(charset)
            }
            val lineEnding = if (rawText.contains("\r\n")) "CRLF" else "LF"
            AppResult.Success(
                EditorDocumentState(
                    filePath = file.absolutePath,
                    fileName = file.name,
                    content = rawText,
                    savedDiskModifiedTime = file.lastModified(),
                    isDirty = false,
                    isReadOnly = isLarge || !file.canWrite(),
                    encodingName = charset.displayName(),
                    lineEndingStyle = lineEnding
                )
            )
        } catch (e: Exception) {
            AppResult.Error("Failed to open text file: ${e.message}", e)
        }
    }

    fun applyEdit(state: EditorDocumentState, newContent: String): EditorDocumentState {
        if (state.isReadOnly || newContent == state.content) return state
        val updatedUndo = (state.undoStack + state.content).takeLast(MAX_UNDO_HISTORY)
        return state.copy(
            content = newContent,
            isDirty = true,
            undoStack = updatedUndo,
            redoStack = emptyList()
        )
    }

    fun undo(state: EditorDocumentState): EditorDocumentState {
        if (state.undoStack.isEmpty()) return state
        val previous = state.undoStack.last()
        val remainingUndo = state.undoStack.dropLast(1)
        val updatedRedo = (state.redoStack + state.content).takeLast(MAX_UNDO_HISTORY)
        return state.copy(
            content = previous,
            isDirty = true,
            undoStack = remainingUndo,
            redoStack = updatedRedo
        )
    }

    fun redo(state: EditorDocumentState): EditorDocumentState {
        if (state.redoStack.isEmpty()) return state
        val next = state.redoStack.last()
        val remainingRedo = state.redoStack.dropLast(1)
        val updatedUndo = (state.undoStack + state.content).takeLast(MAX_UNDO_HISTORY)
        return state.copy(
            content = next,
            isDirty = true,
            undoStack = updatedUndo,
            redoStack = remainingRedo
        )
    }

    fun computeStats(text: String): TextDocumentStats {
        val lines = if (text.isEmpty()) 1 else text.count { it == '\n' } + 1
        val words = text.trim().let { trimmed ->
            if (trimmed.isEmpty()) 0 else trimmed.split(Regex("\\s+")).size
        }
        return TextDocumentStats(
            charCount = text.length,
            lineCount = lines,
            wordCount = words,
            byteCountUtf8 = text.toByteArray(Charsets.UTF_8).size
        )
    }

    fun saveDocument(
        state: EditorDocumentState,
        targetFile: File,
        forceOverwriteExternalChanges: Boolean = false
    ): AppResult<EditorDocumentState> {
        if (state.isReadOnly && targetFile.absolutePath == state.filePath) {
            return AppResult.Error("Document is opened in Read-Only mode. Use Save As to write to a new file.")
        }
        if (!forceOverwriteExternalChanges &&
            targetFile.exists() &&
            targetFile.absolutePath == state.filePath &&
            targetFile.lastModified() != state.savedDiskModifiedTime
        ) {
            return AppResult.Error("Conflict detected: File was modified outside the editor since it was opened.")
        }
        return try {
            val normalizedContent = if (state.lineEndingStyle == "CRLF") {
                state.content.replace("\r\n", "\n").replace("\n", "\r\n")
            } else {
                state.content.replace("\r\n", "\n")
            }
            targetFile.writeText(normalizedContent, Charset.forName(state.encodingName))
            AppResult.Success(
                state.copy(
                    filePath = targetFile.absolutePath,
                    fileName = targetFile.name,
                    savedDiskModifiedTime = targetFile.lastModified(),
                    isDirty = false
                )
            )
        } catch (e: Exception) {
            AppResult.Error("Save failed: ${e.message}", e)
        }
    }

    /**
     * Validates regex patterns and guards against pathological nested quantifiers.
     */
    fun safeFindMatches(
        text: String,
        query: String,
        useRegex: Boolean,
        caseSensitive: Boolean
    ): AppResult<List<IntRange>> {
        if (query.isEmpty()) return AppResult.Success(emptyList())
        when (val compiled = compileSafeRegex(query, useRegex, caseSensitive)) {
            is AppResult.Error -> return compiled
            is AppResult.Success -> {
                val ranges = compiled.data.findAll(text).take(5_000).map { it.range }.toList()
                return AppResult.Success(ranges)
            }
        }
    }

    fun replaceAllMatches(
        state: EditorDocumentState,
        query: String,
        replacement: String,
        useRegex: Boolean,
        caseSensitive: Boolean
    ): AppResult<Pair<EditorDocumentState, Int>> {
        if (state.isReadOnly) {
            return AppResult.Error("Cannot replace text in Read-Only mode.")
        }
        if (query.isEmpty()) {
            return AppResult.Error("Enter a search query to replace.")
        }
        return when (val compiled = compileSafeRegex(query, useRegex, caseSensitive)) {
            is AppResult.Error -> compiled
            is AppResult.Success -> {
                try {
                    val regex = compiled.data
                    val matchCount = regex.findAll(state.content).count()
                    if (matchCount == 0) {
                        return AppResult.Success(state to 0)
                    }
                    val updatedText = if (useRegex) {
                        regex.replace(state.content, replacement)
                    } else {
                        regex.replace(state.content, Regex.escapeReplacement(replacement))
                    }
                    AppResult.Success(applyEdit(state, updatedText) to matchCount)
                } catch (e: Exception) {
                    AppResult.Error("Replace failed: ${e.message}", e)
                }
            }
        }
    }

    private fun compileSafeRegex(
        query: String,
        useRegex: Boolean,
        caseSensitive: Boolean
    ): AppResult<Regex> {
        if (useRegex && query.length > MAX_REGEX_PATTERN_LENGTH) {
            return AppResult.Error("Regex pattern exceeds maximum safe length ($MAX_REGEX_PATTERN_LENGTH chars).")
        }
        if (useRegex && Regex("(\\([^)]*[+*][^)]*\\))[+*?]").containsMatchIn(query)) {
            return AppResult.Error("Rejected potentially catastrophic nested-quantifier regular expression.")
        }
        return try {
            val options = if (caseSensitive) emptySet() else setOf(RegexOption.IGNORE_CASE)
            val regex = if (useRegex) Regex(query, options) else Regex(Regex.escape(query), options)
            AppResult.Success(regex)
        } catch (e: Exception) {
            AppResult.Error("Invalid search pattern: ${e.message}", e)
        }
    }
}
