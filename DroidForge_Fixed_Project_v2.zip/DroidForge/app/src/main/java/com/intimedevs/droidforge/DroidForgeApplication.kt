package com.intimedevs.droidforge

import android.app.Application
import java.io.File

class DroidForgeApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        seedSampleWorkspaceIfNeeded()
    }

    private fun seedSampleWorkspaceIfNeeded() {
        val sampleRoot = File(filesDir, "Workspace")
        if (!sampleRoot.exists()) {
            sampleRoot.mkdirs()
            File(sampleRoot, "Documents").mkdirs()
            File(sampleRoot, "Projects").mkdirs()
            File(sampleRoot, "Archives").mkdirs()
            File(sampleRoot, "APKs").mkdirs()
            File(sampleRoot, "Documents/welcome_notes.md").writeText(
                "# Welcome to DroidForge\n\nSafe, offline-first Android file manager and APK inspection toolkit.\n"
            )
            File(sampleRoot, "Projects/config_v1.json").writeText(
                "{\n  \"app\": \"DroidForge\",\n  \"minSdk\": 26,\n  \"scopedStorage\": true\n}\n"
            )
            File(sampleRoot, "Projects/config_v2.json").writeText(
                "{\n  \"app\": \"DroidForge\",\n  \"minSdk\": 26,\n  \"scopedStorage\": true,\n  \"zipSlipGuard\": true\n}\n"
            )
        }
    }
}
