package com.intimedevs.droidforge.core.database

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "task_records")
data class TaskRecordEntity(
    @PrimaryKey val id: String,
    val title: String,
    val operationType: String,
    val sourceSummary: String,
    val destinationSummary: String,
    val status: String,
    val progressPercent: Int,
    val errorDetails: String?,
    val startedAtMillis: Long,
    val completedAtMillis: Long?
)

@Entity(tableName = "pinned_bookmarks")
data class PinnedBookmarkEntity(
    @PrimaryKey val pathOrUri: String,
    val label: String,
    val addedAtMillis: Long
)

@Dao
interface DroidForgeDao {
    @Query("SELECT * FROM task_records ORDER BY startedAtMillis DESC LIMIT 100")
    fun observeTasks(): Flow<List<TaskRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTask(task: TaskRecordEntity)

    @Query("DELETE FROM task_records")
    suspend fun clearTaskHistory()

    @Query("SELECT * FROM pinned_bookmarks ORDER BY addedAtMillis DESC")
    fun observeBookmarks(): Flow<List<PinnedBookmarkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBookmark(bookmark: PinnedBookmarkEntity)

    @Query("DELETE FROM pinned_bookmarks WHERE pathOrUri = :pathOrUri")
    suspend fun removeBookmark(pathOrUri: String)
}

@Database(
    entities = [TaskRecordEntity::class, PinnedBookmarkEntity::class],
    version = 1,
    exportSchema = false
)
abstract class DroidForgeDatabase : RoomDatabase() {
    abstract fun dao(): DroidForgeDao
}
