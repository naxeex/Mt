package com.intimedevs.droidforge.core.storage

data class FileNode(
    val id: String,
    val name: String,
    val pathOrUri: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val lastModifiedMillis: Long,
    val mimeType: String,
    val isHidden: Boolean = name.startsWith("."),
    val isSymbolicLink: Boolean = false,
    val canRead: Boolean = true,
    val canWrite: Boolean = true,
    val storageRootLabel: String = "App Workspace"
) {
    val extension: String
        get() = if (isDirectory) "" else name.substringAfterLast('.', "").lowercase()
}

data class StorageLocationSummary(
    val id: String,
    val label: String,
    val uriOrPath: String,
    val totalBytes: Long,
    val usedBytes: Long,
    val freeBytes: Long,
    val isSafTree: Boolean,
    val permissionGranted: Boolean
)
