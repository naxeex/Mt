package com.intimedevs.droidforge.feature.hexviewer

import com.intimedevs.droidforge.core.common.AppResult
import java.io.File
import java.io.RandomAccessFile

data class HexRow(
    val offset: Long,
    val bytes: ByteArray,
    val hexColumns: List<String>,
    val asciiRepresentation: String
)

data class HexPage(
    val fileOffset: Long,
    val totalFileSize: Long,
    val rows: List<HexRow>
)

class ChunkedHexReader {

    /**
     * Reads a fixed window of bytes using RandomAccessFile so multi-gigabyte files never load into RAM.
     */
    fun readChunk(file: File, offset: Long, byteCount: Int = 512): AppResult<HexPage> {
        if (!file.exists() || !file.isFile || !file.canRead()) {
            return AppResult.Error("Cannot read binary file: ${file.name}")
        }
        val safeOffset = offset.coerceAtLeast(0L)
        val safeLength = byteCount.coerceIn(16, 16 * 1024)
        return try {
            RandomAccessFile(file, "r").use { raf ->
                val totalSize = raf.length()
                if (safeOffset >= totalSize && totalSize > 0) {
                    return AppResult.Error("Offset 0x${safeOffset.toString(16).uppercase()} is past end of file ($totalSize bytes).")
                }
                val toRead = minOf(safeLength.toLong(), (totalSize - safeOffset).coerceAtLeast(0L)).toInt()
                val buffer = ByteArray(toRead)
                if (toRead > 0) {
                    raf.seek(safeOffset)
                    raf.readFully(buffer)
                }
                val rows = buffer.toList().chunked(16).mapIndexed { rowIndex, rowBytes ->
                    val raw = rowBytes.toByteArray()
                    val hexCols = raw.map { "%02X".format(it) }
                    val ascii = raw.map { b ->
                        val c = b.toInt() and 0xFF
                        if (c in 32..126) c.toChar() else '.'
                    }.joinToString("")
                    HexRow(
                        offset = safeOffset + (rowIndex * 16L),
                        bytes = raw,
                        hexColumns = hexCols,
                        asciiRepresentation = ascii
                    )
                }
                AppResult.Success(HexPage(safeOffset, totalSize, rows))
            }
        } catch (e: Exception) {
            AppResult.Error("Hex reader error: ${e.message}", e)
        }
    }

    /**
     * Parses a hex string such as "4D 5A 90 00" or "4d5a9000" into a ByteArray.
     */
    fun parseHexString(hexInput: String): AppResult<ByteArray> {
        val cleaned = hexInput
            .replace("0x", "", ignoreCase = true)
            .replace(Regex("[\\s,:-]+"), "")
        if (cleaned.isEmpty()) {
            return AppResult.Error("Enter at least one hex byte (for example: 50 4B 03 04).")
        }
        if (cleaned.length % 2 != 0) {
            return AppResult.Error("Hex string must have an even number of hex digits.")
        }
        if (!cleaned.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) {
            return AppResult.Error("Hex string contains invalid non-hexadecimal characters.")
        }
        return try {
            val out = ByteArray(cleaned.length / 2) { i ->
                cleaned.substring(i * 2, i * 2 + 2).toInt(16).toByte()
            }
            AppResult.Success(out)
        } catch (e: Exception) {
            AppResult.Error("Failed to parse hex bytes: ${e.message}", e)
        }
    }

    /**
     * Writes patched bytes at the specified offset using RandomAccessFile.
     */
    fun writeBytesAtOffset(file: File, offset: Long, patchBytes: ByteArray): AppResult<Int> {
        if (!file.exists() || !file.isFile || !file.canWrite()) {
            return AppResult.Error("File is not writable: ${file.name}")
        }
        if (offset < 0L) {
            return AppResult.Error("Offset cannot be negative.")
        }
        if (patchBytes.isEmpty()) {
            return AppResult.Error("Patch byte array is empty.")
        }
        return try {
            RandomAccessFile(file, "rw").use { raf ->
                if (offset > raf.length()) {
                    return AppResult.Error("Offset 0x${offset.toString(16).uppercase()} exceeds file size (${raf.length()} bytes).")
                }
                raf.seek(offset)
                raf.write(patchBytes)
            }
            AppResult.Success(patchBytes.size)
        } catch (e: Exception) {
            AppResult.Error("Failed to patch bytes: ${e.message}", e)
        }
    }

    /**
     * Searches for a byte sequence (from hex or ASCII query) in a binary file using sliding-window chunks.
     */
    fun searchBytes(
        file: File,
        pattern: ByteArray,
        startOffset: Long = 0L,
        maxMatches: Int = 50
    ): AppResult<List<Long>> {
        if (!file.exists() || !file.isFile || !file.canRead()) {
            return AppResult.Error("Cannot read file for binary search: ${file.name}")
        }
        if (pattern.isEmpty() || pattern.size > 1024) {
            return AppResult.Error("Search pattern must be between 1 and 1024 bytes.")
        }
        return try {
            val matches = mutableListOf<Long>()
            RandomAccessFile(file, "r").use { raf ->
                val fileLen = raf.length()
                var pos = startOffset.coerceAtLeast(0L)
                val windowSize = 64 * 1024
                val buffer = ByteArray(windowSize)
                while (pos < fileLen && matches.size < maxMatches) {
                    raf.seek(pos)
                    val read = raf.read(buffer)
                    if (read < pattern.size) break
                    val limit = read - pattern.size
                    for (i in 0..limit) {
                        var match = true
                        for (j in pattern.indices) {
                            if (buffer[i + j] != pattern[j]) {
                                match = false
                                break
                            }
                        }
                        if (match) {
                            matches += pos + i
                            if (matches.size >= maxMatches) break
                        }
                    }
                    if (read < windowSize) break
                    pos += read - pattern.size + 1
                }
            }
            AppResult.Success(matches)
        } catch (e: Exception) {
            AppResult.Error("Binary search failed: ${e.message}", e)
        }
    }
}
