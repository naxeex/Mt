package com.intimedevs.droidforge.core.fileops

import com.intimedevs.droidforge.core.common.AppResult
import java.io.File
import java.io.FileInputStream
import java.nio.file.Files
import java.security.MessageDigest

enum class ConflictPolicy {
    SKIP,
    REPLACE,
    KEEP_BOTH
}

enum class SortField { NAME, EXTENSION, SIZE, MODIFIED_DATE, TYPE }

data class OperationProgress(
    val processedItems: Int,
    val totalItems: Int,
    val currentFileName: String,
    val bytesProcessed: Long
)

data class OperationReport(
    val succeededCount: Int,
    val skippedCount: Int,
    val failedItems: List<Pair<String, String>>
)

data class FileChecksums(
    val md5: String,
    val sha256: String,
    val sizeBytes: Long,
    val securityNotice: String = "MD5 is for legacy compatibility checks only; rely on SHA-256 for security verification."
)

data class BatchRenamePreviewItem(
    val originalFile: File,
    val originalName: String,
    val proposedName: String,
    val hasCollision: Boolean,
    val collisionReason: String? = null,
    val sourceIdOrUri: String = originalFile.path
)

data class DiffLine(
    val lineNumberLeft: Int?,
    val lineNumberRight: Int?,
    val content: String,
    val type: DiffType
)

enum class DiffType { UNCHANGED, ADDED, REMOVED }

class FileOperationsEngine {

    fun copyOrMoveFiles(
        sources: List<File>,
        destinationDir: File,
        move: Boolean,
        conflictPolicy: ConflictPolicy,
        isCancelled: () -> Boolean = { false },
        onProgress: (OperationProgress) -> Unit = {}
    ): AppResult<OperationReport> {
        if (!destinationDir.exists() && !destinationDir.mkdirs()) {
            return AppResult.Error("Destination directory could not be created: ${destinationDir.name}")
        }
        if (!destinationDir.canWrite()) {
            return AppResult.Error("Destination is read-only: ${destinationDir.name}")
        }

        var succeeded = 0
        var skipped = 0
        val failures = mutableListOf<Pair<String, String>>()
        var bytesDone = 0L

        for ((index, src) in sources.withIndex()) {
            if (isCancelled()) {
                return AppResult.Success(
                    OperationReport(succeeded, skipped, failures + ("Operation" to "Cancelled by user"))
                )
            }
            onProgress(OperationProgress(index, sources.size, src.name, bytesDone))

            try {
                if (Files.isSymbolicLink(src.toPath())) {
                    skipped++
                    failures += src.name to "Skipped symbolic link for safety"
                    continue
                }
                if (src.isDirectory && destinationDir.canonicalPath.startsWith(src.canonicalPath)) {
                    failures += src.name to "Cannot copy or move a folder into itself"
                    continue
                }

                var target = File(destinationDir, src.name)
                if (target.exists()) {
                    when (conflictPolicy) {
                        ConflictPolicy.SKIP -> {
                            skipped++
                            continue
                        }
                        ConflictPolicy.REPLACE -> {
                            if (target.canonicalPath == src.canonicalPath) {
                                skipped++
                                continue
                            }
                            target.deleteRecursively()
                        }
                        ConflictPolicy.KEEP_BOTH -> {
                            target = resolveUniqueFile(destinationDir, src.name, src.isDirectory)
                        }
                    }
                }

                if (src.isDirectory) {
                    src.copyRecursively(target, overwrite = conflictPolicy == ConflictPolicy.REPLACE)
                } else {
                    src.copyTo(target, overwrite = conflictPolicy == ConflictPolicy.REPLACE)
                    bytesDone += src.length()
                }

                if (move) {
                    if (!src.deleteRecursively()) {
                        failures += src.name to "Copied to destination, but original could not be deleted"
                    }
                }
                succeeded++
            } catch (e: Exception) {
                failures += src.name to (e.message ?: "Unknown I/O error")
            }
        }
        onProgress(OperationProgress(sources.size, sources.size, "Complete", bytesDone))
        return AppResult.Success(OperationReport(succeeded, skipped, failures))
    }

    fun resolveUniqueFile(parent: File, originalName: String, isDirectory: Boolean): File {
        val base = if (isDirectory) originalName else originalName.substringBeforeLast('.', originalName)
        val ext = if (isDirectory || !originalName.contains('.')) "" else ".${originalName.substringAfterLast('.')}"
        var counter = 1
        var candidate = File(parent, "${base}_($counter)$ext")
        while (candidate.exists()) {
            counter++
            candidate = File(parent, "${base}_($counter)$ext")
        }
        return candidate
    }

    fun computeChecksums(file: File): AppResult<FileChecksums> {
        if (!file.exists() || !file.isFile) {
            return AppResult.Error("File is not readable or is a directory: ${file.name}")
        }
        return try {
            val md5Digest = MessageDigest.getInstance("MD5")
            val sha256Digest = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            FileInputStream(file).use { fis ->
                var read = fis.read(buffer)
                while (read > 0) {
                    md5Digest.update(buffer, 0, read)
                    sha256Digest.update(buffer, 0, read)
                    read = fis.read(buffer)
                }
            }
            AppResult.Success(
                FileChecksums(
                    md5 = md5Digest.digest().joinToString("") { "%02x".format(it) },
                    sha256 = sha256Digest.digest().joinToString("") { "%02x".format(it) },
                    sizeBytes = file.length()
                )
            )
        } catch (e: Exception) {
            AppResult.Error("Checksum calculation failed: ${e.message}", e)
        }
    }

    fun previewBatchRename(
        files: List<File>,
        prefix: String = "",
        suffix: String = "",
        findText: String = "",
        replaceText: String = "",
        startNumber: Int? = null
    ): List<BatchRenamePreviewItem> {
        val parentExistingNames = files.firstOrNull()?.parentFile?.list()?.toSet().orEmpty()
        return previewBatchRenameNamedEntries(
            entries = files.map { Triple(it, it.name, it.isDirectory) },
            existingSiblingNames = parentExistingNames,
            prefix = prefix,
            suffix = suffix,
            findText = findText,
            replaceText = replaceText,
            startNumber = startNumber
        )
    }

    fun previewBatchRenameNamedEntries(
        entries: List<Triple<File, String, Boolean>>,
        existingSiblingNames: Set<String>,
        prefix: String = "",
        suffix: String = "",
        findText: String = "",
        replaceText: String = "",
        startNumber: Int? = null
    ): List<BatchRenamePreviewItem> {
        val selectedOriginalNames = entries.map { it.second }.toSet()
        val seenTargets = mutableSetOf<String>()

        return entries.mapIndexed { index, (file, rawName, isDir) ->
            val stem = if (isDir) rawName else rawName.substringBeforeLast('.', rawName)
            val ext = if (isDir || !rawName.contains('.')) "" else ".${rawName.substringAfterLast('.')}"

            val replacedStem = if (findText.isNotEmpty()) stem.replace(findText, replaceText) else stem
            val numberPart = if (startNumber != null) "_%02d".format(startNumber + index) else ""
            val newName = "$prefix$replacedStem$suffix$numberPart$ext".trim()

            val invalidChars = newName.isEmpty() || newName.contains('/') || newName.contains('\u0000') || newName == "." || newName == ".."
            val duplicateInBatch = !seenTargets.add(newName.lowercase())
            val existsInFolder = newName !in selectedOriginalNames && newName in existingSiblingNames

            val reason = when {
                invalidChars -> "Invalid filename characters"
                duplicateInBatch -> "Duplicate target name within batch"
                existsInFolder -> "File with this name already exists in folder"
                else -> null
            }

            BatchRenamePreviewItem(
                originalFile = file,
                originalName = rawName,
                proposedName = newName,
                hasCollision = reason != null,
                collisionReason = reason,
                sourceIdOrUri = file.path
            )
        }
    }

    /**
     * Executes a validated batch rename on local files using two-phase temporary names
     * so swaps or overlapping names within the batch never clobber one another.
     */
    fun applyBatchRename(items: List<BatchRenamePreviewItem>): AppResult<Int> {
        val actionable = items.filter { it.originalName != it.proposedName }
        if (actionable.isEmpty()) return AppResult.Success(0)
        val firstCollision = items.firstOrNull { it.hasCollision }
        if (firstCollision != null) {
            return AppResult.Error("Cannot batch rename: ${firstCollision.originalName} -> ${firstCollision.collisionReason}")
        }
        return try {
            val staged = mutableListOf<Pair<File, File>>()
            val nonce = System.currentTimeMillis()
            for ((idx, item) in actionable.withIndex()) {
                val src = item.originalFile
                val parent = src.parentFile ?: return AppResult.Error("Missing parent folder for ${src.name}")
                val tempFile = File(parent, ".droidforge_rename_${nonce}_$idx.tmp")
                val finalFile = File(parent, item.proposedName)
                if (!src.renameTo(tempFile)) {
                    // Rollback already staged files
                    staged.forEach { (tmp, _) ->
                        val origName = actionable[staged.indexOf(tmp to finalFile)].originalFile
                        tmp.renameTo(origName)
                    }
                    return AppResult.Error("Failed staging rename for ${src.name}")
                }
                staged += tempFile to finalFile
            }
            var renamedCount = 0
            for ((tempFile, finalFile) in staged) {
                if (tempFile.renameTo(finalFile)) {
                    renamedCount++
                }
            }
            AppResult.Success(renamedCount)
        } catch (e: Exception) {
            AppResult.Error("Batch rename failed: ${e.message}", e)
        }
    }

    fun compareTextFiles(leftFile: File, rightFile: File, maxBytes: Long = 2 * 1024 * 1024): AppResult<List<DiffLine>> {
        if (leftFile.length() > maxBytes || rightFile.length() > maxBytes) {
            return AppResult.Error("Files exceed 2 MB text diff safety threshold; use checksum/binary compare instead.")
        }
        return try {
            val leftLines = leftFile.readLines(Charsets.UTF_8)
            val rightLines = rightFile.readLines(Charsets.UTF_8)
            val result = mutableListOf<DiffLine>()
            var i = 0
            var j = 0
            while (i < leftLines.size || j < rightLines.size) {
                val l = leftLines.getOrNull(i)
                val r = rightLines.getOrNull(j)
                when {
                    l != null && r != null && l == r -> {
                        result += DiffLine(i + 1, j + 1, l, DiffType.UNCHANGED)
                        i++; j++
                    }
                    l != null && (r == null || !rightLines.drop(j).take(3).contains(l)) -> {
                        result += DiffLine(i + 1, null, l, DiffType.REMOVED)
                        i++
                    }
                    r != null -> {
                        result += DiffLine(null, j + 1, r, DiffType.ADDED)
                        j++
                    }
                    else -> break
                }
                if (result.size > 5000) break
            }
            AppResult.Success(result)
        } catch (e: Exception) {
            AppResult.Error("Failed to compare text files: ${e.message}", e)
        }
    }

    fun findDuplicateFiles(rootDir: File): AppResult<Map<String, List<File>>> {
        return try {
            val bySize = rootDir.walkTopDown()
                .onEnter { !Files.isSymbolicLink(it.toPath()) }
                .filter { it.isFile && it.length() > 0L && it.canRead() }
                .groupBy { it.length() }
                .filterValues { it.size > 1 }

            val duplicatesByHash = mutableMapOf<String, MutableList<File>>()
            for ((_, sameSizeFiles) in bySize) {
                for (file in sameSizeFiles) {
                    when (val checksum = computeChecksums(file)) {
                        is AppResult.Success -> {
                            val key = "${checksum.data.sizeBytes}:${checksum.data.sha256}"
                            duplicatesByHash.getOrPut(key) { mutableListOf() }.add(file)
                        }
                        is AppResult.Error -> Unit
                    }
                }
            }
            AppResult.Success(duplicatesByHash.filterValues { it.size > 1 })
        } catch (e: Exception) {
            AppResult.Error("Duplicate scan failed: ${e.message}", e)
        }
    }
}
