package com.intimedevs.droidforge.core.storage

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.StatFs
import androidx.documentfile.provider.DocumentFile
import com.intimedevs.droidforge.core.common.AppResult
import com.intimedevs.droidforge.core.fileops.BatchRenamePreviewItem
import com.intimedevs.droidforge.core.fileops.ConflictPolicy
import com.intimedevs.droidforge.core.fileops.OperationReport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.file.Files

class StorageRepository(private val context: Context) {

    fun getAccessibleLocations(): List<StorageLocationSummary> {
        val list = mutableListOf<StorageLocationSummary>()
        val internalDir = context.filesDir
        val stat = StatFs(internalDir.absolutePath)
        val total = stat.totalBytes
        val free = stat.availableBytes
        list += StorageLocationSummary(
            id = "internal_workspace",
            label = "App Sandbox Workspace",
            uriOrPath = internalDir.absolutePath,
            totalBytes = total,
            usedBytes = (total - free).coerceAtLeast(0L),
            freeBytes = free,
            isSafTree = false,
            permissionGranted = true
        )

        for (perm in context.contentResolver.persistedUriPermissions) {
            if (perm.isReadPermission || perm.isWritePermission) {
                val doc = DocumentFile.fromTreeUri(context, perm.uri)
                val canAccess = doc != null && doc.canRead()
                list += StorageLocationSummary(
                    id = perm.uri.toString(),
                    label = doc?.name ?: "SAF Folder (${perm.uri.lastPathSegment})",
                    uriOrPath = perm.uri.toString(),
                    totalBytes = 0L,
                    usedBytes = 0L,
                    freeBytes = 0L,
                    isSafTree = true,
                    permissionGranted = canAccess
                )
            }
        }
        return list
    }

    fun persistSafTreePermission(
        treeUri: Uri,
        grantedFlags: Int = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
    ): AppResult<Unit> {
        return try {
            val flags = grantedFlags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            context.contentResolver.takePersistableUriPermission(treeUri, flags)
            AppResult.Success(Unit)
        } catch (e: SecurityException) {
            AppResult.Error("Could not persist SAF folder access: ${e.message}", e)
        }
    }

    fun releaseSafTreePermission(treeUri: Uri): AppResult<Unit> {
        return try {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            context.contentResolver.releasePersistableUriPermission(treeUri, flags)
            AppResult.Success(Unit)
        } catch (e: Exception) {
            AppResult.Error("Could not release SAF folder permission: ${e.message}", e)
        }
    }

    private fun resolveDocumentFile(uri: Uri): DocumentFile? {
        return DocumentFile.fromTreeUri(context, uri)
            ?: DocumentFile.fromSingleUri(context, uri)
    }

    /** Lists a directory selected through ACTION_OPEN_DOCUMENT_TREE or one of its child URIs. */
    suspend fun listSafDirectory(
        directoryUri: Uri,
        includeHidden: Boolean = false
    ): AppResult<List<FileNode>> = withContext(Dispatchers.IO) {
        try {
            val directory = resolveDocumentFile(directoryUri)
                ?: return@withContext AppResult.Error("This storage location is no longer available. Select the folder again.")
            if (!directory.exists() || !directory.isDirectory || !directory.canRead()) {
                return@withContext AppResult.Error("Cannot read this folder. Its permission may have been revoked.")
            }
            val children = directory.listFiles().filter { includeHidden || !(it.name ?: "").startsWith(".") }
            AppResult.Success(children.map { doc ->
                val name = doc.name ?: "(unnamed)"
                FileNode(
                    id = doc.uri.toString(),
                    name = name,
                    pathOrUri = doc.uri.toString(),
                    isDirectory = doc.isDirectory,
                    sizeBytes = doc.length().coerceAtLeast(0L),
                    lastModifiedMillis = doc.lastModified().coerceAtLeast(0L),
                    mimeType = doc.type ?: if (doc.isDirectory) "vnd.android.document/directory" else guessMimeType(File(name)),
                    isHidden = name.startsWith("."),
                    isSymbolicLink = false,
                    canRead = doc.canRead(),
                    canWrite = doc.canWrite(),
                    storageRootLabel = "Selected SAF folder"
                )
            })
        } catch (e: Exception) {
            AppResult.Error("Failed to list selected folder: ${e.message}", e)
        }
    }

    fun createSafDirectory(parentUri: Uri, name: String): AppResult<Uri> {
        val safeName = name.trim()
        if (safeName.isEmpty() || safeName in setOf(".", "..") || safeName.contains('/')) {
            return AppResult.Error("Enter a valid folder name.")
        }
        return try {
            val parent = resolveDocumentFile(parentUri)
                ?: return AppResult.Error("Selected folder is unavailable.")
            val created = parent.createDirectory(safeName)
                ?: return AppResult.Error("Could not create folder. Check write permission and name conflicts.")
            AppResult.Success(created.uri)
        } catch (e: Exception) {
            AppResult.Error("Create folder failed: ${e.message}", e)
        }
    }

    fun renameSafDocument(documentUri: Uri, newName: String): AppResult<Uri> {
        val safeName = newName.trim()
        if (safeName.isEmpty() || safeName in setOf(".", "..") || safeName.contains('/')) {
            return AppResult.Error("Enter a valid name.")
        }
        return try {
            val doc = resolveDocumentFile(documentUri)
                ?: return AppResult.Error("Selected item is unavailable.")
            val renamed = doc.renameTo(safeName)
            if (!renamed) AppResult.Error("Rename failed. The provider may not support renaming this item.")
            else AppResult.Success(doc.uri)
        } catch (e: Exception) {
            AppResult.Error("Rename failed: ${e.message}", e)
        }
    }

    fun deleteSafDocument(documentUri: Uri): AppResult<Unit> {
        return try {
            val doc = resolveDocumentFile(documentUri)
                ?: return AppResult.Error("Selected item is unavailable.")
            if (doc.delete()) AppResult.Success(Unit)
            else AppResult.Error("Delete failed. The provider may not allow deleting this item.")
        } catch (e: Exception) {
            AppResult.Error("Delete failed: ${e.message}", e)
        }
    }

    fun copySafDocumentToCache(documentUri: Uri, displayName: String): AppResult<File> {
        return try {
            val safeName = displayName.substringAfterLast('/').ifBlank { "document.bin" }
            val destination = File(context.cacheDir, "droidforge_${System.currentTimeMillis()}_$safeName")
            context.contentResolver.openInputStream(documentUri)?.use { input ->
                destination.outputStream().buffered().use { output -> input.copyTo(output) }
            } ?: return AppResult.Error("Could not open selected item for reading.")
            AppResult.Success(destination)
        } catch (e: Exception) {
            AppResult.Error("Could not prepare file for inspection: ${e.message}", e)
        }
    }

    fun writeTextToSafDocument(documentUri: Uri, content: String): AppResult<Unit> {
        return try {
            context.contentResolver.openOutputStream(documentUri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use {
                it.write(content)
            } ?: return AppResult.Error("Could not open this document for writing.")
            AppResult.Success(Unit)
        } catch (e: Exception) {
            AppResult.Error("Could not save document: ${e.message}", e)
        }
    }

    fun writeBytesToSafDocument(documentUri: Uri, bytes: ByteArray): AppResult<Unit> {
        return try {
            context.contentResolver.openOutputStream(documentUri, "wt")?.buffered()?.use {
                it.write(bytes)
            } ?: return AppResult.Error("Could not open this document for binary writing.")
            AppResult.Success(Unit)
        } catch (e: Exception) {
            AppResult.Error("Could not save binary document: ${e.message}", e)
        }
    }

    /**
     * Copies or moves a list of FileNodes (from either Workspace or SAF) into either a Workspace
     * directory (`destWorkspaceDir != null`) or a SAF directory (`destSafDirUri != null`).
     */
    suspend fun copyOrMoveNodes(
        sources: List<FileNode>,
        destWorkspaceDir: File?,
        destSafDirUri: Uri?,
        move: Boolean,
        conflictPolicy: ConflictPolicy = ConflictPolicy.KEEP_BOTH
    ): AppResult<OperationReport> = withContext(Dispatchers.IO) {
        var succeeded = 0
        var skipped = 0
        val failures = mutableListOf<Pair<String, String>>()

        val destSafDir = if (destSafDirUri != null) {
            val doc = resolveDocumentFile(destSafDirUri)
            if (doc == null || !doc.exists() || !doc.isDirectory || !doc.canWrite()) {
                return@withContext AppResult.Error("Destination SAF folder is unavailable or read-only.")
            }
            doc
        } else null

        if (destWorkspaceDir != null) {
            if (!destWorkspaceDir.exists() && !destWorkspaceDir.mkdirs()) {
                return@withContext AppResult.Error("Could not create destination Workspace folder.")
            }
            if (!destWorkspaceDir.canWrite()) {
                return@withContext AppResult.Error("Destination Workspace folder is read-only.")
            }
        }

        for (node in sources) {
            try {
                val isSourceSaf = node.pathOrUri.startsWith("content://")
                val copiedOk = when {
                    !isSourceSaf && destWorkspaceDir != null -> {
                        copyLocalToLocal(File(node.pathOrUri), destWorkspaceDir, conflictPolicy)
                    }
                    !isSourceSaf && destSafDir != null -> {
                        copyLocalToSaf(File(node.pathOrUri), destSafDir, conflictPolicy)
                    }
                    isSourceSaf && destWorkspaceDir != null -> {
                        val srcDoc = resolveDocumentFile(Uri.parse(node.pathOrUri))
                            ?: throw IllegalStateException("Source SAF item unavailable")
                        copySafToLocal(srcDoc, destWorkspaceDir, conflictPolicy)
                    }
                    isSourceSaf && destSafDir != null -> {
                        val srcDoc = resolveDocumentFile(Uri.parse(node.pathOrUri))
                            ?: throw IllegalStateException("Source SAF item unavailable")
                        copySafToSaf(srcDoc, destSafDir, conflictPolicy)
                    }
                    else -> false
                }

                if (!copiedOk) {
                    skipped++
                    continue
                }

                if (move) {
                    val deleted = if (isSourceSaf) {
                        resolveDocumentFile(Uri.parse(node.pathOrUri))?.delete() == true
                    } else {
                        File(node.pathOrUri).deleteRecursively()
                    }
                    if (!deleted) {
                        failures += node.name to "Copied to destination, but source could not be deleted"
                    }
                }
                succeeded++
            } catch (e: Exception) {
                failures += node.name to (e.message ?: "Transfer failed")
            }
        }

        AppResult.Success(OperationReport(succeeded, skipped, failures))
    }

    private fun copyLocalToLocal(src: File, destDir: File, policy: ConflictPolicy): Boolean {
        if (!src.exists()) throw IllegalStateException("Source file does not exist")
        if (Files.isSymbolicLink(src.toPath())) throw IllegalStateException("Symbolic links are skipped for safety")
        if (src.isDirectory && destDir.canonicalPath.startsWith(src.canonicalPath)) {
            throw IllegalStateException("Cannot copy or move a folder into itself")
        }
        var target = File(destDir, src.name)
        if (target.exists()) {
            when (policy) {
                ConflictPolicy.SKIP -> return false
                ConflictPolicy.REPLACE -> {
                    if (target.canonicalPath == src.canonicalPath) return false
                    target.deleteRecursively()
                }
                ConflictPolicy.KEEP_BOTH -> target = resolveUniqueLocalFile(destDir, src.name, src.isDirectory)
            }
        }
        if (src.isDirectory) {
            src.copyRecursively(target, overwrite = true)
        } else {
            src.copyTo(target, overwrite = true)
        }
        return true
    }

    private fun copyLocalToSaf(src: File, destSafDir: DocumentFile, policy: ConflictPolicy): Boolean {
        if (!src.exists()) throw IllegalStateException("Source file does not exist")
        if (Files.isSymbolicLink(src.toPath())) throw IllegalStateException("Symbolic links are skipped for safety")
        val existing = destSafDir.findFile(src.name)
        val targetName = if (existing != null) {
            when (policy) {
                ConflictPolicy.SKIP -> return false
                ConflictPolicy.REPLACE -> {
                    existing.delete()
                    src.name
                }
                ConflictPolicy.KEEP_BOTH -> resolveUniqueSafName(destSafDir, src.name, src.isDirectory)
            }
        } else src.name

        if (src.isDirectory) {
            val childDir = destSafDir.createDirectory(targetName)
                ?: throw IllegalStateException("Could not create SAF directory $targetName")
            src.listFiles()?.forEach { child ->
                copyLocalToSaf(child, childDir, policy)
            }
        } else {
            val mime = guessMimeType(src)
            val created = destSafDir.createFile(mime, targetName)
                ?: throw IllegalStateException("Could not create SAF file $targetName")
            src.inputStream().buffered().use { input ->
                context.contentResolver.openOutputStream(created.uri, "w")?.buffered()?.use { output ->
                    input.copyTo(output)
                } ?: throw IllegalStateException("Could not open SAF output stream for $targetName")
            }
        }
        return true
    }

    private fun copySafToLocal(srcDoc: DocumentFile, destDir: File, policy: ConflictPolicy): Boolean {
        val rawName = srcDoc.name ?: "unnamed_item"
        var target = File(destDir, rawName)
        if (target.exists()) {
            when (policy) {
                ConflictPolicy.SKIP -> return false
                ConflictPolicy.REPLACE -> target.deleteRecursively()
                ConflictPolicy.KEEP_BOTH -> target = resolveUniqueLocalFile(destDir, rawName, srcDoc.isDirectory)
            }
        }
        if (srcDoc.isDirectory) {
            if (!target.mkdirs() && !target.exists()) {
                throw IllegalStateException("Could not create local folder ${target.name}")
            }
            srcDoc.listFiles().forEach { child ->
                copySafToLocal(child, target, policy)
            }
        } else {
            context.contentResolver.openInputStream(srcDoc.uri)?.buffered()?.use { input ->
                target.outputStream().buffered().use { output ->
                    input.copyTo(output)
                }
            } ?: throw IllegalStateException("Could not read SAF source $rawName")
        }
        return true
    }

    private fun copySafToSaf(srcDoc: DocumentFile, destSafDir: DocumentFile, policy: ConflictPolicy): Boolean {
        val rawName = srcDoc.name ?: "unnamed_item"
        if (srcDoc.isDirectory && destSafDir.uri.toString().startsWith(srcDoc.uri.toString())) {
            throw IllegalStateException("Cannot copy or move a SAF folder into itself")
        }
        val existing = destSafDir.findFile(rawName)
        val targetName = if (existing != null) {
            when (policy) {
                ConflictPolicy.SKIP -> return false
                ConflictPolicy.REPLACE -> {
                    if (existing.uri == srcDoc.uri) return false
                    existing.delete()
                    rawName
                }
                ConflictPolicy.KEEP_BOTH -> resolveUniqueSafName(destSafDir, rawName, srcDoc.isDirectory)
            }
        } else rawName

        if (srcDoc.isDirectory) {
            val childDir = destSafDir.createDirectory(targetName)
                ?: throw IllegalStateException("Could not create SAF folder $targetName")
            srcDoc.listFiles().forEach { child ->
                copySafToSaf(child, childDir, policy)
            }
        } else {
            val mime = srcDoc.type ?: guessMimeType(File(targetName))
            val created = destSafDir.createFile(mime, targetName)
                ?: throw IllegalStateException("Could not create SAF file $targetName")
            context.contentResolver.openInputStream(srcDoc.uri)?.buffered()?.use { input ->
                context.contentResolver.openOutputStream(created.uri, "w")?.buffered()?.use { output ->
                    input.copyTo(output)
                } ?: throw IllegalStateException("Could not write to SAF file $targetName")
            } ?: throw IllegalStateException("Could not read from SAF file $rawName")
        }
        return true
    }

    /**
     * Copies an extracted local directory tree directly into a destination SAF directory.
     */
    suspend fun copyDirectoryContentsToSaf(sourceDir: File, destSafUri: Uri): AppResult<Int> = withContext(Dispatchers.IO) {
        val destDoc = resolveDocumentFile(destSafUri)
            ?: return@withContext AppResult.Error("Destination SAF folder is unavailable.")
        if (!destDoc.isDirectory || !destDoc.canWrite()) {
            return@withContext AppResult.Error("Destination SAF folder is not writable.")
        }
        var copiedFiles = 0
        try {
            fun copyChildren(localParent: File, safParent: DocumentFile) {
                localParent.listFiles()?.forEach { child ->
                    if (child.isDirectory) {
                        val existingDir = safParent.findFile(child.name)?.takeIf { it.isDirectory }
                            ?: safParent.createDirectory(child.name)
                            ?: throw IllegalStateException("Could not create SAF folder ${child.name}")
                        copyChildren(child, existingDir)
                    } else {
                        safParent.findFile(child.name)?.delete()
                        val created = safParent.createFile(guessMimeType(child), child.name)
                            ?: throw IllegalStateException("Could not create SAF file ${child.name}")
                        child.inputStream().buffered().use { input ->
                            context.contentResolver.openOutputStream(created.uri, "w")?.buffered()?.use { output ->
                                input.copyTo(output)
                            } ?: throw IllegalStateException("Failed writing SAF file ${child.name}")
                        }
                        copiedFiles++
                    }
                }
            }
            copyChildren(sourceDir, destDoc)
            AppResult.Success(copiedFiles)
        } catch (e: Exception) {
            AppResult.Error("Failed copying extracted files to SAF folder: ${e.message}", e)
        }
    }

    private fun resolveUniqueLocalFile(parent: File, originalName: String, isDirectory: Boolean): File {
        val base = if (isDirectory) originalName else originalName.substringBeforeLast('.', originalName)
        val ext = if (isDirectory || !originalName.contains('.')) "" else ".${originalName.substringAfterLast('.')}"
        var counter = 1
        var candidate = File(parent, "${base}_($counter)$ext")
        while (candidate.exists()) {
            counter++
            candidate = File(parent, "${base}_($counter)$ext")
        }
        return candidate
    }

    private fun resolveUniqueSafName(parent: DocumentFile, originalName: String, isDirectory: Boolean): String {
        val base = if (isDirectory) originalName else originalName.substringBeforeLast('.', originalName)
        val ext = if (isDirectory || !originalName.contains('.')) "" else ".${originalName.substringAfterLast('.')}"
        var counter = 1
        var candidate = "${base}_($counter)$ext"
        while (parent.findFile(candidate) != null) {
            counter++
            candidate = "${base}_($counter)$ext"
        }
        return candidate
    }

    suspend fun listDirectory(
        directory: File,
        includeHidden: Boolean = false
    ): AppResult<List<FileNode>> = withContext(Dispatchers.IO) {
        try {
            if (!directory.exists()) {
                return@withContext AppResult.Error("Folder does not exist: ${directory.name}")
            }
            if (!directory.canRead()) {
                return@withContext AppResult.Error(
                    "Permission denied reading ${directory.name}. Android restricts direct access to protected paths without SAF selection."
                )
            }
            val children = directory.listFiles().orEmpty()
            val nodes = children
                .filter { includeHidden || !it.name.startsWith(".") }
                .map { file ->
                    val isSymlink = try {
                        Files.isSymbolicLink(file.toPath())
                    } catch (_: Throwable) {
                        false
                    }
                    FileNode(
                        id = file.absolutePath,
                        name = file.name,
                        pathOrUri = file.absolutePath,
                        isDirectory = file.isDirectory && !isSymlink,
                        sizeBytes = if (file.isDirectory) 0L else file.length(),
                        lastModifiedMillis = file.lastModified(),
                        mimeType = guessMimeType(file),
                        isHidden = file.name.startsWith("."),
                        isSymbolicLink = isSymlink,
                        canRead = file.canRead(),
                        canWrite = file.canWrite()
                    )
                }
            AppResult.Success(nodes)
        } catch (e: Exception) {
            AppResult.Error("Failed to list directory: ${e.message}", e)
        }
    }

    fun guessMimeType(file: File): String {
        if (file.isDirectory) return "vnd.android.document/directory"
        return when (file.extension.lowercase()) {
            "txt", "md", "log", "ini", "cfg" -> "text/plain"
            "json" -> "application/json"
            "xml", "axml" -> "application/xml"
            "kt", "java", "py", "sh", "js", "css", "html" -> "text/x-source"
            "zip", "jar" -> "application/zip"
            "apk", "apks", "xapk" -> "application/vnd.android.package-archive"
            "png", "jpg", "jpeg", "webp" -> "image/*"
            "mp3", "wav", "ogg" -> "audio/*"
            "mp4", "mkv", "webm" -> "video/*"
            "pdf" -> "application/pdf"
            else -> "application/octet-stream"
        }
    }
}
