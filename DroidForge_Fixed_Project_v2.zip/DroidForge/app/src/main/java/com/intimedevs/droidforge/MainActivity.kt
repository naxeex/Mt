package com.intimedevs.droidforge

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.intimedevs.droidforge.core.designsystem.DroidForgeTheme
import com.intimedevs.droidforge.ui.DroidForgeAppRoot

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DroidForgeTheme {
                DroidForgeAppRoot()
            }
        }
    }
}
