package com.intimedevs.droidforge.feature.archive

import com.intimedevs.droidforge.core.common.AppResult
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

data class ArchiveEntryNode(
    val path: String,
    val isDirectory: Boolean,
    val compressedSize: Long,
    val uncompressedSize: Long,
    val crc: Long,
    val lastModifiedMillis: Long,
    val isSuspiciousTraversal: Boolean
)

class ZipArchiveEngine {

    companion object {
        private const val MAX_ENTRIES = 25_000
        private const val MAX_TOTAL_UNCOMPRESSED_BYTES = 2L * 1024L * 1024L * 1024L // 2 GB decompression bomb guard
    }

    fun listEntries(zipFile: File): AppResult<List<ArchiveEntryNode>> {
        if (!zipFile.exists() || !zipFile.canRead()) {
            return AppResult.Error("Cannot read archive: ${zipFile.name}")
        }
        return try {
            ZipFile(zipFile).use { zf ->
                val entries = mutableListOf<ArchiveEntryNode>()
                val enumeration = zf.entries()
                var count = 0
                while (enumeration.hasMoreElements()) {
                    count++
                    if (count > MAX_ENTRIES) {
                        return AppResult.Error("Archive exceeds maximum safe entry count ($MAX_ENTRIES).")
                    }
                    val entry = enumeration.nextElement()
                    val normalized = entry.name.replace('\\', '/')
                    val suspicious = normalized.startsWith("/") ||
                        normalized.contains("../") ||
                        normalized.endsWith("/..") ||
                        normalized == ".."
                    entries += ArchiveEntryNode(
                        path = entry.name,
                        isDirectory = entry.isDirectory,
                        compressedSize = entry.compressedSize.coerceAtLeast(0L),
                        uncompressedSize = entry.size.coerceAtLeast(0L),
                        crc = entry.crc,
                        lastModifiedMillis = entry.time,
                        isSuspiciousTraversal = suspicious
                    )
                }
                AppResult.Success(entries)
            }
        } catch (e: Exception) {
            AppResult.Error("Corrupt or unsupported ZIP archive: ${e.message}", e)
        }
    }

    /**
     * Extracts entries with strict canonical-path Zip-Slip protection and decompression-bomb limits.
     */
    fun extractArchive(
        zipFile: File,
        destinationDir: File,
        selectedEntryPaths: Set<String>? = null
    ): AppResult<Int> {
        return try {
            if (!destinationDir.exists() && !destinationDir.mkdirs()) {
                return AppResult.Error("Could not create destination folder: ${destinationDir.name}")
            }
            val canonicalDestDirPath = destinationDir.canonicalPath + File.separator
            var extractedCount = 0
            var totalBytesWritten = 0L

            ZipFile(zipFile).use { zf ->
                val enumeration = zf.entries()
                while (enumeration.hasMoreElements()) {
                    val entry = enumeration.nextElement()
                    if (selectedEntryPaths != null && entry.name !in selectedEntryPaths) {
                        continue
                    }

                    val targetFile = File(destinationDir, entry.name)
                    val canonicalTargetPath = targetFile.canonicalPath
                    if (!canonicalTargetPath.startsWith(canonicalDestDirPath) &&
                        canonicalTargetPath != destinationDir.canonicalPath
                    ) {
                        return AppResult.Error(
                            "Security Error (Zip-Slip blocked): Entry '${entry.name}' attempted to write outside destination directory."
                        )
                    }

                    if (entry.isDirectory) {
                        targetFile.mkdirs()
                    } else {
                        targetFile.parentFile?.mkdirs()
                        zf.getInputStream(entry).use { input ->
                            BufferedOutputStream(FileOutputStream(targetFile)).use { output ->
                                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                                var read = input.read(buffer)
                                while (read != -1) {
                                    totalBytesWritten += read
                                    if (totalBytesWritten > MAX_TOTAL_UNCOMPRESSED_BYTES) {
                                        targetFile.delete()
                                        return AppResult.Error("Extraction aborted: Archive exceeded decompression safety limit.")
                                    }
                                    output.write(buffer, 0, read)
                                    read = input.read(buffer)
                                }
                            }
                        }
                        extractedCount++
                    }
                }
            }
            AppResult.Success(extractedCount)
        } catch (e: Exception) {
            AppResult.Error("Archive extraction failed: ${e.message}", e)
        }
    }

    fun createZipArchive(
        sources: List<File>,
        outputZipFile: File,
        compressionLevel: Int = Deflater.DEFAULT_COMPRESSION
    ): AppResult<Long> {
        return try {
            outputZipFile.parentFile?.mkdirs()
            ZipOutputStream(BufferedOutputStream(FileOutputStream(outputZipFile))).use { zos ->
                zos.setLevel(compressionLevel.coerceIn(0, 9))
                for (src in sources) {
                    addFileToZip(zos, src, src.name)
                }
            }
            AppResult.Success(outputZipFile.length())
        } catch (e: Exception) {
            AppResult.Error("Failed to create ZIP archive: ${e.message}", e)
        }
    }

    private fun addFileToZip(zos: ZipOutputStream, file: File, entryName: String) {
        if (file.isDirectory) {
            val normalized = if (entryName.endsWith("/")) entryName else "$entryName/"
            zos.putNextEntry(ZipEntry(normalized))
            zos.closeEntry()
            file.listFiles()?.forEach { child ->
                addFileToZip(zos, child, "$normalized${child.name}")
            }
        } else {
            BufferedInputStream(FileInputStream(file)).use { bis ->
                val entry = ZipEntry(entryName).apply { time = file.lastModified() }
                zos.putNextEntry(entry)
                bis.copyTo(zos)
                zos.closeEntry()
            }
        }
    }
}
