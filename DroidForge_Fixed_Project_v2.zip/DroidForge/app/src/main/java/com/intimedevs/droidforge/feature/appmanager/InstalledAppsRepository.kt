package com.intimedevs.droidforge.feature.appmanager

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.intimedevs.droidforge.core.common.AppResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class InstalledAppItem(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val minSdk: Int,
    val targetSdk: Int,
    val isSystemApp: Boolean,
    val sourceApkPath: String,
    val apkSizeBytes: Long,
    val lastUpdateTimeMillis: Long,
    val requestedPermissions: List<String>
)

class InstalledAppsRepository(private val context: Context) {

    suspend fun loadInstalledApps(includeSystemApps: Boolean): AppResult<List<InstalledAppItem>> =
        withContext(Dispatchers.IO) {
            try {
                val pm = context.packageManager
                val packages: List<PackageInfo> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
                }

                val items = packages.mapNotNull { pkg ->
                    val appInfo = pkg.applicationInfo ?: return@mapNotNull null
                    val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    if (!includeSystemApps && isSystem) return@mapNotNull null

                    val apkFile = appInfo.sourceDir?.let { File(it) }
                    val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        pkg.longVersionCode
                    } else {
                        @Suppress("DEPRECATION")
                        pkg.versionCode.toLong()
                    }
                    InstalledAppItem(
                        appName = pm.getApplicationLabel(appInfo).toString(),
                        packageName = pkg.packageName,
                        versionName = pkg.versionName ?: "N/A",
                        versionCode = versionCode,
                        minSdk = appInfo.minSdkVersion,
                        targetSdk = appInfo.targetSdkVersion,
                        isSystemApp = isSystem,
                        sourceApkPath = appInfo.sourceDir.orEmpty(),
                        apkSizeBytes = apkFile?.length() ?: 0L,
                        lastUpdateTimeMillis = pkg.lastUpdateTime,
                        requestedPermissions = pkg.requestedPermissions?.toList().orEmpty()
                    )
                }.sortedBy { it.appName.lowercase() }

                AppResult.Success(items)
            } catch (e: Exception) {
                AppResult.Error("Failed to query installed packages: ${e.message}", e)
            }
        }

    /**
     * Copies the installed package's base APK (`sourceApkPath`) into the app-private Workspace/APKs directory.
     */
    suspend fun backupApkToWorkspace(app: InstalledAppItem, workspaceRoot: File): AppResult<File> =
        withContext(Dispatchers.IO) {
            try {
                if (app.sourceApkPath.isBlank()) {
                    return@withContext AppResult.Error("Base APK path is unavailable for ${app.packageName}.")
                }
                val sourceFile = File(app.sourceApkPath)
                if (!sourceFile.exists() || !sourceFile.canRead()) {
                    return@withContext AppResult.Error("Cannot read installed base APK for ${app.packageName}.")
                }
                val apksDir = File(workspaceRoot, "APKs").apply { mkdirs() }
                val safeVersion = app.versionName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
                val targetFile = File(apksDir, "${app.packageName}_v${safeVersion}_${app.versionCode}.apk")
                sourceFile.inputStream().buffered().use { input ->
                    targetFile.outputStream().buffered().use { output ->
                        input.copyTo(output)
                    }
                }
                AppResult.Success(targetFile)
            } catch (e: Exception) {
                AppResult.Error("APK backup failed: ${e.message}", e)
            }
        }

    fun openSystemAppDetails(packageName: String): AppResult<Unit> {
        return try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            AppResult.Success(Unit)
        } catch (e: Exception) {
            AppResult.Error("Could not open system App Info screen: ${e.message}", e)
        }
    }
}
