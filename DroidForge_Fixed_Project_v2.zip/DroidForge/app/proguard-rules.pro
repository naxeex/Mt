# DroidForge ProGuard Rules
-keepattributes Signature, InnerClasses, EnclosingMethod
-dontwarn org.apache.commons.compress.**
