@echo off
setlocal
set GRADLE_VERSION=8.9
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set INSTALL_DIR=%GRADLE_USER_HOME%\droidforge-bootstrap\gradle-%GRADLE_VERSION%
set GRADLE_BIN=%INSTALL_DIR%\bin\gradle.bat
if exist "%GRADLE_BIN%" goto run_gradle
if not exist "%GRADLE_USER_HOME%\droidforge-bootstrap" mkdir "%GRADLE_USER_HOME%\droidforge-bootstrap"
set ZIP=%GRADLE_USER_HOME%\droidforge-bootstrap\gradle-%GRADLE_VERSION%-bin.zip
echo Downloading Gradle %GRADLE_VERSION%...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
if errorlevel 1 exit /b 1
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%GRADLE_USER_HOME%\droidforge-bootstrap'"
if errorlevel 1 exit /b 1
:run_gradle
call "%GRADLE_BIN%" %*
exit /b %ERRORLEVEL%
