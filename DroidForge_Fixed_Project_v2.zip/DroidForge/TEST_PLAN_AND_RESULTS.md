# Test Plan and Verification Status

## Included fixtures (`sample_fixtures/`)

- `config_v1.ini` and `config_v2.ini`: text and comparison samples.
- `sample_firmware_chunk.bin`: binary sample for hex-reader and byte-patching testing.
- `sample_safe_archive.zip`: valid ZIP sample.
- `zip_slip_traversal_test.zip`: traversal-path sample (`../../`) for extraction security testing.
- `sample_inspectable_app_v1.apk` and `sample_inspectable_app_v2.apk`: synthetic APK fixtures with plain-XML manifests and DEX headers.
- `sample_binary_axml_v2sig.apk`: synthetic APK fixture containing a binary `AndroidManifest.xml` (`0x00080003` AXML chunk format), `classes.dex` (`039`), and an `APK Sig Block 42` with v2 (`0x7109871a`) and v3 (`0xf05368c0`) signing block IDs.

## Verification Summary

| Check / Test Case | Status | Notes |
| :--- | :--- | :--- |
| Kotlin syntax, delimiter & import audit | PASS | Verified all 13 `.kt` source and test files |
| Embedded NUL-byte check | PASS | 0 embedded NUL bytes across all project files |
| Gradle bootstrap shell syntax (`bash -n gradlew`) | PASS | Clean POSIX/bash syntax |
| Binary AXML (`0x00080003`) fixture & structure check | PASS | Verified string pool, resource map, and start/end element chunks |
| APK Signing Block (`APK Sig Block 42`) v2/v3 layout check | PASS | Verified EOCD Central Directory offset & v2/v3 ID-value pairs |
| ZIP archive integrity (`DroidForge_Updated_Project.zip`) | PASS | Verified all entries with `zipfile.testzip()` |
| Full Android Gradle build (`./gradlew assembleDebug`) | UNVERIFIED | Requires Android SDK & network access in Android Studio |
| Emulator / physical-device runtime testing | UNVERIFIED | Run in Android Studio on API 26+ device/emulator |

## Recommended Device Tests in Android Studio

1. **Multi-select & Cross-Storage Copy/Move**:
   - Tap the checkbox icon in **Files**, select multiple files/folders in Workspace, tap **Copy** or **Cut**, switch to a granted SAF folder, cycle the conflict policy (`KEEP_BOTH` / `REPLACE` / `SKIP`), and tap **Paste Here**.
2. **Batch Rename**:
   - Multi-select several items in **Files**, tap **Batch Rename**, enter a prefix/suffix or find/replace with numbering enabled, verify live collision warnings, and tap **Apply Rename**.
3. **Interactive Hex Viewer & Byte Patcher**:
   - Open `sample_firmware_chunk.bin` in **Hex Viewer**, test **Prev / Next** 512-byte pagination, search for a hex sequence or ASCII string, and apply a byte patch at a hex offset.
4. **Text Editor (Undo/Redo & Find/Replace)**:
   - Open `welcome_notes.md`, make several edits, test **Undo** and **Redo**, open the **Find & Replace** bar (`Aa` / `Regex`), run **Replace All**, and tap **Save**.
5. **APK Inspector (Binary AXML, Signing Block & Certificates)**:
   - Inspect `sample_binary_axml_v2sig.apk` or any installed app from the **Apps** tab (**Inspect** button) to verify binary `AndroidManifest.xml` decoding, v1/v2/v3 signing block detection, X.509 certificate fingerprints, and DEX header counts.
6. **Installed APK Backup & Direct SAF ZIP Extraction**:
   - In **Apps**, tap **Backup** on an installed package and verify the APK is saved under `Workspace/APKs/`.
   - In **Files**, select a `.zip` archive inside a SAF folder and test **Extract Archive to Current Folder**.
